package com.example.ui.packages

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.environment.PackageItem
import com.example.core.environment.PackageRegistry
import com.example.ui.theme.TerminalMonoFontFamily
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow
import kotlinx.coroutines.launch

@Composable
fun PackagesScreen(
  onRunTerminalCommand: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val packages by PackageRegistry.packages.collectAsState()
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("All") }

  var activeLogPkgName by remember { mutableStateOf<String?>(null) }
  var installLogs by remember { mutableStateOf<List<String>>(emptyList()) }
  var isInstalling by remember { mutableStateOf(false) }

  val scope = rememberCoroutineScope()

  LaunchedEffect(Unit) {
    PackageRegistry.refreshInstalledState()
  }

  val categories = listOf("All", "Installed", "Development", "Compilers", "Network", "Editors", "Database")

  val filteredPackages = remember(packages, searchQuery, selectedCategory) {
    packages.filter { pkg ->
      val matchesSearch = searchQuery.isBlank() ||
        pkg.name.contains(searchQuery, ignoreCase = true) ||
        pkg.id.contains(searchQuery, ignoreCase = true) ||
        pkg.description.contains(searchQuery, ignoreCase = true)

      val matchesCategory = when (selectedCategory) {
        "All" -> true
        "Installed" -> pkg.isInstalled
        else -> pkg.category.equals(selectedCategory, ignoreCase = true)
      }
      matchesSearch && matchesCategory
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(TermBackground)
  ) {
    // Header & Quick Command Buttons
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TermSurface)
        .border(0.5.dp, TermBorder)
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Widgets,
          contentDescription = "Packages",
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp)
        )
        Text(
          text = "Package Manager (pkg)",
          color = TermTextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(
          onClick = {
            onRunTerminalCommand("pkg update")
          },
          shape = RoundedCornerShape(6.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TermTextPrimary),
          border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(TermBorder)),
          modifier = Modifier.height(30.dp)
        ) {
          Icon(Icons.Default.Refresh, contentDescription = "Update", modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("update", fontSize = 11.sp)
        }

        OutlinedButton(
          onClick = {
            onRunTerminalCommand("pkg upgrade")
          },
          shape = RoundedCornerShape(6.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TermGreen),
          border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(TermGreen)),
          modifier = Modifier.height(30.dp)
        ) {
          Icon(Icons.Default.SystemUpdate, contentDescription = "Upgrade", modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("upgrade", fontSize = 11.sp)
        }
      }
    }

    // Search bar
    Box(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search packages (python, git, clang...)", color = TermTextMuted, fontSize = 13.sp) },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = "Search", tint = TermTextMuted, modifier = Modifier.size(18.dp))
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = TermSurface,
          unfocusedContainerColor = TermSurface,
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = TermBorder,
          focusedTextColor = TermTextPrimary,
          unfocusedTextColor = TermTextPrimary
        )
      )
    }

    // Category Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 10.dp, vertical = 2.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      categories.forEach { cat ->
        val isSelected = selectedCategory == cat
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else TermSurfaceVariant)
            .border(
              1.dp,
              if (isSelected) MaterialTheme.colorScheme.primary else TermBorder,
              RoundedCornerShape(16.dp)
            )
            .clickable { selectedCategory = cat }
            .padding(horizontal = 12.dp, vertical = 5.dp)
        ) {
          Text(
            text = cat,
            color = if (isSelected) MaterialTheme.colorScheme.primary else TermTextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Packages List
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(filteredPackages, key = { it.id }) { pkg ->
        PackageCard(
          pkg = pkg,
          onInstall = {
            activeLogPkgName = pkg.name
            installLogs = emptyList()
            isInstalling = true
            scope.launch {
              PackageRegistry.installPackage(pkg.id) { log ->
                installLogs = installLogs + log
              }
              isInstalling = false
            }
          },
          onUninstall = {
            activeLogPkgName = pkg.name
            installLogs = emptyList()
            isInstalling = true
            scope.launch {
              PackageRegistry.removePackage(pkg.id) { log ->
                installLogs = installLogs + log
              }
              isInstalling = false
            }
          }
        )
      }
    }
  }

  // Installation Log Modal Dialog
  activeLogPkgName?.let { pkgTitle ->
    PackageLogDialog(
      packageName = pkgTitle,
      logs = installLogs,
      isInstalling = isInstalling,
      onDismiss = { activeLogPkgName = null }
    )
  }
}

@Composable
private fun PackageCard(
  pkg: PackageItem,
  onInstall: () -> Unit,
  onUninstall: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(TermSurface)
      .border(1.dp, TermBorder, RoundedCornerShape(8.dp))
      .padding(12.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = pkg.name,
            color = TermTextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "v${pkg.version}",
            color = TermCyan,
            fontSize = 11.sp,
            fontFamily = TerminalMonoFontFamily
          )
        }
        Text(
          text = "${pkg.category} • ${pkg.size}",
          color = TermTextMuted,
          fontSize = 11.sp
        )
      }

      if (pkg.isInstalled) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(TermGreen.copy(alpha = 0.2f))
              .border(0.5.dp, TermGreen, RoundedCornerShape(4.dp))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text("Installed", color = TermGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }

          IconButton(
            onClick = onUninstall,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(Icons.Default.Delete, contentDescription = "Uninstall", tint = TermRed, modifier = Modifier.size(16.dp))
          }
        }
      } else {
        Button(
          onClick = onInstall,
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.height(30.dp)
        ) {
          Icon(Icons.Default.Download, contentDescription = "Install", tint = Color.Black, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Install", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Description
    Text(
      text = pkg.description,
      color = TermTextMuted,
      fontSize = 12.sp,
      lineHeight = 16.sp
    )

    Spacer(modifier = Modifier.height(8.dp))

    // Binaries & Dependencies tags
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      if (pkg.binaries.isNotEmpty()) {
        Text(
          text = "Binaries: ${pkg.binaries.joinToString(", ")}",
          color = TermYellow,
          fontSize = 10.sp,
          fontFamily = TerminalMonoFontFamily
        )
      }
      if (pkg.dependencies.isNotEmpty()) {
        Text(
          text = "Deps: ${pkg.dependencies.joinToString(", ")}",
          color = TermTextMuted,
          fontSize = 10.sp
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PackageLogDialog(
  packageName: String,
  logs: List<String>,
  isInstalling: Boolean,
  onDismiss: () -> Unit
) {
  BasicAlertDialog(
    onDismissRequest = { if (!isInstalling) onDismiss() },
    modifier = Modifier
      .fillMaxWidth(0.92f)
      .clip(RoundedCornerShape(12.dp))
      .background(TermSurface)
      .border(1.dp, TermBorder, RoundedCornerShape(12.dp))
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (isInstalling) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.primary, strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.Check, contentDescription = "Done", tint = TermGreen, modifier = Modifier.size(18.dp))
          }
          Text(
            text = "Package: $packageName",
            color = TermTextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }

        if (!isInstalling) {
          IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TermTextMuted)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Terminal-style logs
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(min = 120.dp, max = 240.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(TermBackground)
          .border(0.5.dp, TermBorder)
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        items(logs) { log ->
          Text(
            text = log,
            color = if (log.contains("✔")) TermGreen else if (log.contains("Error")) TermRed else TermTextPrimary,
            fontSize = 11.sp,
            fontFamily = TerminalMonoFontFamily
          )
        }
      }

      if (!isInstalling) {
        Spacer(modifier = Modifier.height(12.dp))
        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("Done", color = Color.Black, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

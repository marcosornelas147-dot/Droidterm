package com.example.ui.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.environment.LinuxEnvironment
import com.example.core.terminal.TerminalManager
import com.example.core.terminal.TerminalSession
import com.example.ui.components.SpecialKeysBar
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermPromptPath
import com.example.ui.theme.TermPromptUser
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow
import kotlinx.coroutines.launch

@Composable
fun TerminalScreen(
  onOpenAi: () -> Unit,
  fontSizeSp: Int = 13,
  modifier: Modifier = Modifier
) {
  val sessions by TerminalManager.sessions.collectAsState()
  val activeIndex by TerminalManager.activeSessionIndex.collectAsState()
  val activeSession = sessions.getOrNull(activeIndex)

  var commandInput by remember { mutableStateOf("") }
  var showHistoryDialog by remember { mutableStateOf(false) }
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()
  val focusManager = LocalFocusManager.current

  val lines = activeSession?.lines?.collectAsState()?.value ?: emptyList()
  val isRunning = activeSession?.isRunning?.collectAsState()?.value ?: false
  val currentDir = activeSession?.currentDir?.collectAsState()?.value ?: LinuxEnvironment.homeDir

  // Auto-scroll to bottom when new lines are appended
  LaunchedEffect(lines.size) {
    if (lines.isNotEmpty()) {
      listState.animateScrollToItem(lines.size - 1)
    }
  }

  // Calculate autocomplete suggestions
  val autocompleteSuggestions = remember(commandInput, currentDir) {
    computeSuggestions(commandInput, currentDir)
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(TermBackground)
      .imePadding()
  ) {
    // Session Tabs Bar
    SessionTabBar(
      sessions = sessions,
      activeIndex = activeIndex,
      onSelectSession = { TerminalManager.selectSession(it) },
      onCloseSession = { TerminalManager.closeSession(it) },
      onAddSession = { TerminalManager.createNewSession() }
    )

    // Terminal Scrollback Area
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
      LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize()
      ) {
        items(lines, key = { it.id }) { line ->
          Text(
            text = line.annotatedText,
            fontSize = fontSizeSp.sp,
            lineHeight = (fontSizeSp + 4).sp,
            modifier = Modifier.fillMaxWidth()
          )
        }
      }

      // Indicator when process is running in background
      if (isRunning) {
        Row(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(8.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(TermSurface.copy(alpha = 0.9f))
            .border(1.dp, TermCyan, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          CircularProgressIndicator(
            modifier = Modifier.size(12.dp),
            strokeWidth = 2.dp,
            color = TermCyan
          )
          Text("Running", color = TermCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          IconButton(
            onClick = { activeSession?.sendInterrupt() },
            modifier = Modifier.size(18.dp)
          ) {
            Icon(Icons.Default.Stop, contentDescription = "Stop", tint = TermRed, modifier = Modifier.size(14.dp))
          }
        }
      }
    }

    // Autocomplete Chips
    if (autocompleteSuggestions.isNotEmpty() && !isRunning) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(TermSurfaceVariant)
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        autocompleteSuggestions.forEach { suggestion ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(TermSurface)
              .border(0.5.dp, TermBorder, RoundedCornerShape(4.dp))
              .clickable {
                commandInput = applySuggestion(commandInput, suggestion)
              }
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = suggestion,
              color = TermGreen,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }
    }

    // Prompt & Input Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(TermSurface)
        .padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Prompt Indicator
      Text(
        text = "${formatPromptDir(currentDir)} $ ",
        color = TermPromptPath,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
      )

      // Command input text field
      OutlinedTextField(
        value = commandInput,
        onValueChange = { commandInput = it },
        singleLine = true,
        placeholder = { Text("type command...", color = TermTextMuted, fontSize = 12.sp) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(
          onSend = {
            if (commandInput.isNotBlank()) {
              activeSession?.executeCommand(commandInput)
              commandInput = ""
            }
          }
        ),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = TermBackground,
          unfocusedContainerColor = TermBackground,
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = TermBorder,
          focusedTextColor = TermTextPrimary,
          unfocusedTextColor = TermTextPrimary
        ),
        modifier = Modifier
          .weight(1f)
          .height(46.dp)
      )

      Spacer(modifier = Modifier.width(4.dp))

      // History up
      IconButton(
        onClick = {
          activeSession?.navigateHistory(-1)?.let { commandInput = it }
        },
        modifier = Modifier.size(34.dp)
      ) {
        Icon(Icons.Default.ArrowUpward, contentDescription = "History Up", tint = TermTextMuted, modifier = Modifier.size(18.dp))
      }

      // History list dialog button
      IconButton(
        onClick = { showHistoryDialog = true },
        modifier = Modifier.size(34.dp)
      ) {
        Icon(Icons.Default.History, contentDescription = "History", tint = TermYellow, modifier = Modifier.size(18.dp))
      }

      // Send Command Button
      IconButton(
        onClick = {
          if (commandInput.isNotBlank()) {
            activeSession?.executeCommand(commandInput)
            commandInput = ""
          }
        },
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primary)
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = Color.Black, modifier = Modifier.size(20.dp))
      }
    }

    // Special Keys Bar (CTRL, ALT, ESC, TAB, Arrows, Symbols)
    SpecialKeysBar(
      onKeyPress = { key ->
        when (key) {
          "UP" -> activeSession?.navigateHistory(-1)?.let { commandInput = it }
          "DOWN" -> activeSession?.navigateHistory(1)?.let { commandInput = it }
          "LEFT", "RIGHT" -> {}
          "\t" -> {
            if (autocompleteSuggestions.isNotEmpty()) {
              commandInput = applySuggestion(commandInput, autocompleteSuggestions.first())
            }
          }
          "\u001B" -> commandInput = "" // ESC clears current line input
          else -> commandInput += key
        }
      },
      onCtrlC = {
        activeSession?.sendInterrupt()
      },
      onCtrlD = {
        activeSession?.sendEof()
      },
      onClear = {
        activeSession?.clear()
      },
      onOpenAi = onOpenAi
    )
  }

  // Command History Modal Dialog
  if (showHistoryDialog) {
    CommandHistoryDialog(
      history = activeSession?.commandHistory ?: emptyList(),
      onSelectCommand = { cmd -> commandInput = cmd },
      onDismiss = { showHistoryDialog = false }
    )
  }
}

@Composable
private fun SessionTabBar(
  sessions: List<TerminalSession>,
  activeIndex: Int,
  onSelectSession: (Int) -> Unit,
  onCloseSession: (Int) -> Unit,
  onAddSession: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(TermSurface)
      .border(0.5.dp, TermBorder)
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 6.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    sessions.forEachIndexed { index, session ->
      val isActive = index == activeIndex
      val tabTitle by session.title.collectAsState()

      Row(
        modifier = Modifier
          .height(30.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else TermSurfaceVariant)
          .border(
            1.dp,
            if (isActive) MaterialTheme.colorScheme.primary else TermBorder,
            RoundedCornerShape(6.dp)
          )
          .clickable { onSelectSession(index) }
          .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Box(
          modifier = Modifier
            .size(6.dp)
            .clip(CircleShape)
            .background(if (isActive) TermGreen else TermTextMuted)
        )
        Text(
          text = tabTitle,
          color = if (isActive) MaterialTheme.colorScheme.primary else TermTextPrimary,
          fontSize = 11.sp,
          fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
        )
        if (sessions.size > 1) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close Tab",
            tint = TermTextMuted,
            modifier = Modifier
              .size(14.dp)
              .clickable { onCloseSession(index) }
          )
        }
      }
    }

    // New Tab Button
    IconButton(
      onClick = onAddSession,
      modifier = Modifier
        .size(28.dp)
        .clip(RoundedCornerShape(6.dp))
        .background(TermSurfaceVariant)
    ) {
      Icon(Icons.Default.Add, contentDescription = "New Tab", tint = TermGreen, modifier = Modifier.size(16.dp))
    }
  }
}

private fun formatPromptDir(dir: java.io.File): String {
  val home = LinuxEnvironment.homeDir.absolutePath
  val path = dir.absolutePath
  return when {
    path == home -> "~"
    path.startsWith(home) -> "~" + path.removePrefix(home)
    else -> dir.name.ifEmpty { "/" }
  }
}

private fun computeSuggestions(input: String, currentDir: java.io.File): List<String> {
  val trimmed = input.trimStart()
  val commonCommands = listOf(
    "pkg", "python3", "node", "git", "serve", "neofetch", "ls", "cd", "cat",
    "mkdir", "rm", "cp", "mv", "touch", "grep", "clear", "top", "ps", "uname",
    "df", "free", "help", "chmod", "curl", "wget", "tar", "unzip"
  )

  if (trimmed.isEmpty()) {
    return listOf("ls", "neofetch", "pkg list", "help", "serve 8080")
  }

  // Handle cd suggestions
  if (trimmed.startsWith("cd ")) {
    val sub = trimmed.removePrefix("cd ").trim()
    val dirs = currentDir.listFiles { f -> f.isDirectory }?.map { it.name } ?: emptyList()
    return dirs.filter { it.startsWith(sub, ignoreCase = true) }.take(6)
  }

  // Handle pkg subcommands
  if (trimmed.startsWith("pkg ")) {
    val sub = trimmed.removePrefix("pkg ").trim()
    val pkgOps = listOf("install", "remove", "search", "list", "update", "upgrade", "info")
    return pkgOps.filter { it.startsWith(sub, ignoreCase = true) }
  }

  // Handle git subcommands
  if (trimmed.startsWith("git ")) {
    val sub = trimmed.removePrefix("git ").trim()
    val gitOps = listOf("status", "log", "clone", "commit", "add", "diff", "branch", "init")
    return gitOps.filter { it.startsWith(sub, ignoreCase = true) }
  }

  // Command matching
  val matches = commonCommands.filter { it.startsWith(trimmed, ignoreCase = true) }
  if (matches.isNotEmpty()) return matches.take(6)

  // Files in current directory
  val files = currentDir.listFiles()?.map { it.name } ?: emptyList()
  return files.filter { it.startsWith(trimmed, ignoreCase = true) }.take(6)
}

private fun applySuggestion(currentInput: String, suggestion: String): String {
  if (currentInput.startsWith("cd ")) {
    return "cd $suggestion"
  }
  if (currentInput.startsWith("pkg ")) {
    return "pkg $suggestion"
  }
  if (currentInput.startsWith("git ")) {
    return "git $suggestion"
  }
  return suggestion
}

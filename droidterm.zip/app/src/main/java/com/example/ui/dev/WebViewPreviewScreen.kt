package com.example.ui.dev

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.TerminalMonoFontFamily
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewPreviewDialog(
  url: String,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var webViewRef: WebView? = remember { null }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier.fillMaxSize(),
      color = TermBackground
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Browser navigation header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TermSurface)
            .border(0.5.dp, TermBorder)
            .padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = TermTextPrimary)
            }
            Spacer(modifier = Modifier.width(6.dp))

            // URL Bar
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(6.dp))
                .background(TermBackground)
                .border(0.5.dp, TermBorder, RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = url,
                color = TermGreen,
                fontSize = 12.sp,
                fontFamily = TerminalMonoFontFamily
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            // Reload
            IconButton(
              onClick = { webViewRef?.reload() },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = TermTextPrimary, modifier = Modifier.size(16.dp))
            }

            // Open in external browser
            IconButton(
              onClick = {
                try {
                  val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                  context.startActivity(intent)
                } catch (_: Exception) {}
              },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(Icons.Default.OpenInBrowser, contentDescription = "Open in Chrome", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            }
          }
        }

        // Live WebView
        AndroidView(
          factory = { ctx ->
            WebView(ctx).apply {
              settings.javaScriptEnabled = true
              settings.domStorageEnabled = true
              settings.loadWithOverviewMode = true
              settings.useWideViewPort = true
              webViewClient = object : WebViewClient() {}
              loadUrl(url)
              webViewRef = this
            }
          },
          update = { view ->
            webViewRef = view
          },
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        )
      }
    }
  }
}

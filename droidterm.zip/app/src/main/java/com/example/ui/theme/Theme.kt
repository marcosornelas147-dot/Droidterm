package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class TerminalThemeMode(
  val displayName: String,
  val primaryColor: Color,
  val secondaryColor: Color,
  val backgroundColor: Color,
  val surfaceColor: Color,
  val promptUserColor: Color,
  val promptPathColor: Color
) {
  CYBERPUNK(
    displayName = "Cyberpunk Cyan",
    primaryColor = Color(0xFF06B6D4),
    secondaryColor = Color(0xFFEC4899),
    backgroundColor = Color(0xFF0D1117),
    surfaceColor = Color(0xFF161B22),
    promptUserColor = Color(0xFF38BDF8),
    promptPathColor = Color(0xFFFACC15)
  ),
  MATRIX(
    displayName = "Matrix Green",
    primaryColor = Color(0xFF00FF66),
    secondaryColor = Color(0xFF10B981),
    backgroundColor = Color(0xFF050F07),
    surfaceColor = Color(0xFF0A1F10),
    promptUserColor = Color(0xFF00FF66),
    promptPathColor = Color(0xFF34D399)
  ),
  DRACULA(
    displayName = "Dracula Dark",
    primaryColor = Color(0xFFBD93F9),
    secondaryColor = Color(0xFFFF79C6),
    backgroundColor = Color(0xFF282A36),
    surfaceColor = Color(0xFF343746),
    promptUserColor = Color(0xFF8BE9FD),
    promptPathColor = Color(0xFF50FA7B)
  ),
  MONOKAI(
    displayName = "Monokai Pro",
    primaryColor = Color(0xFFA6E22E),
    secondaryColor = Color(0xFFFD971F),
    backgroundColor = Color(0xFF272822),
    surfaceColor = Color(0xFF383830),
    promptUserColor = Color(0xFF66D9EF),
    promptPathColor = Color(0xFFF92672)
  ),
  AMBER(
    displayName = "Amber CRT",
    primaryColor = Color(0xFFFFB000),
    secondaryColor = Color(0xFFFFCC00),
    backgroundColor = Color(0xFF1A1200),
    surfaceColor = Color(0xFF2E2000),
    promptUserColor = Color(0xFFFFB000),
    promptPathColor = Color(0xFFFFD54F)
  )
}

@Composable
fun DroidTermTheme(
  themeMode: TerminalThemeMode = TerminalThemeMode.CYBERPUNK,
  content: @Composable () -> Unit
) {
  val colorScheme = darkColorScheme(
    primary = themeMode.primaryColor,
    secondary = themeMode.secondaryColor,
    tertiary = TermYellow,
    background = themeMode.backgroundColor,
    surface = themeMode.surfaceColor,
    surfaceVariant = TermSurfaceVariant,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.Black,
    onBackground = TermTextPrimary,
    onSurface = TermTextPrimary,
    outline = TermBorder
  )

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}

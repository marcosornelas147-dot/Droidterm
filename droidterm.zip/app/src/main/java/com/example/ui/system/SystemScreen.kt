package com.example.ui.system

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.environment.LinuxEnvironment
import com.example.core.system.ProcessItem
import com.example.core.system.SystemMonitor
import com.example.ui.theme.TerminalMonoFontFamily
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SystemScreen(
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val cpuUsage by SystemMonitor.cpuUsage.collectAsState()
  val memory by SystemMonitor.memoryMetrics.collectAsState()
  val storage by SystemMonitor.storageMetrics.collectAsState()
  val processes by SystemMonitor.processes.collectAsState()
  val ports by SystemMonitor.ports.collectAsState()

  var processFilter by remember { mutableStateOf("") }
  var showEnvDialog by remember { mutableStateOf(false) }
  var customEnvVars by remember { mutableStateOf(mutableMapOf<String, String>()) }

  val scope = rememberCoroutineScope()

  // Periodic metrics polling
  LaunchedEffect(Unit) {
    while (true) {
      SystemMonitor.updateMetrics(context)
      delay(2500)
    }
  }

  val filteredProcesses = remember(processes, processFilter) {
    if (processFilter.isBlank()) processes
    else processes.filter { it.name.contains(processFilter, ignoreCase = true) || it.pid.toString().contains(processFilter) }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(TermBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Hardware & OS Telemetry Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Hardware & Resource Metrics", color = TermTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            IconButton(
              onClick = { scope.launch { SystemMonitor.updateMetrics(context) } },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TermTextMuted, modifier = Modifier.size(16.dp))
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // CPU Bar
          MetricGauge(
            icon = Icons.Default.Speed,
            title = "CPU Utilization",
            subtitle = "${Runtime.getRuntime().availableProcessors()} Cores (${System.getProperty("os.arch") ?: "arm64"})",
            valueText = "$cpuUsage%",
            progress = cpuUsage / 100f,
            color = if (cpuUsage > 75) TermRed else TermGreen
          )

          Spacer(modifier = Modifier.height(10.dp))

          // RAM Bar
          MetricGauge(
            icon = Icons.Default.Memory,
            title = "RAM Memory",
            subtitle = "${memory.usedMb} MB used / ${memory.availableMb} MB available",
            valueText = "${(memory.percentageUsed * 100).toInt()}%",
            progress = memory.percentageUsed,
            color = MaterialTheme.colorScheme.primary
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Disk Storage Bar
          MetricGauge(
            icon = Icons.Default.Storage,
            title = "Internal Storage (FilesDir)",
            subtitle = String.format("%.1f GB free / %.1f GB total", storage.freeGb, storage.totalGb),
            valueText = "${(storage.percentageUsed * 100).toInt()}%",
            progress = storage.percentageUsed,
            color = MaterialTheme.colorScheme.secondary
          )
        }
      }
    }

    // 2. Port Manager
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Dns, contentDescription = "Ports", tint = TermCyan, modifier = Modifier.size(18.dp))
            Text("Local Port Scanner", color = TermTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(8.dp))

          ports.forEach { portStatus ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (portStatus.isListening) TermGreen else TermTextMuted)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = ":${portStatus.port} - ${portStatus.label}",
                  color = TermTextPrimary,
                  fontSize = 12.sp,
                  fontFamily = TerminalMonoFontFamily
                )
              }
              Text(
                text = if (portStatus.isListening) "LISTENING" else "CLOSED",
                color = if (portStatus.isListening) TermGreen else TermTextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // 3. Process Manager Header & Filter
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Active Processes (${filteredProcesses.size})",
          color = TermTextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )

        Button(
          onClick = { showEnvDialog = true },
          colors = ButtonDefaults.buttonColors(containerColor = TermSurfaceVariant),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.height(30.dp)
        ) {
          Text("Env Vars", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      OutlinedTextField(
        value = processFilter,
        onValueChange = { processFilter = it },
        placeholder = { Text("Filter processes by name or PID...", color = TermTextMuted, fontSize = 12.sp) },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = "Search", tint = TermTextMuted, modifier = Modifier.size(16.dp))
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = TermSurface,
          unfocusedContainerColor = TermSurface,
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = TermBorder,
          focusedTextColor = TermTextPrimary,
          unfocusedTextColor = TermTextPrimary
        )
      )
    }

    // Process Items
    items(filteredProcesses.take(25), key = { it.pid }) { proc ->
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(6.dp))
          .background(TermSurface)
          .border(0.5.dp, TermBorder, RoundedCornerShape(6.dp))
          .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Text(
            text = "${proc.pid}",
            color = TermYellow,
            fontSize = 12.sp,
            fontFamily = TerminalMonoFontFamily,
            modifier = Modifier.width(50.dp)
          )
          Column {
            Text(
              text = proc.name,
              color = TermTextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = "User: ${proc.user} • ${proc.memoryKb} KB",
              color = TermTextMuted,
              fontSize = 10.sp
            )
          }
        }

        IconButton(
          onClick = {
            scope.launch {
              SystemMonitor.killProcess(proc.pid)
              SystemMonitor.updateMetrics(context)
            }
          },
          modifier = Modifier.size(26.dp)
        ) {
          Icon(Icons.Default.Delete, contentDescription = "Kill Process", tint = TermRed, modifier = Modifier.size(16.dp))
        }
      }
    }
  }

  // Environment Variables Dialog
  if (showEnvDialog) {
    EnvVarsDialog(
      onDismiss = { showEnvDialog = false }
    )
  }
}

@Composable
private fun MetricGauge(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
  valueText: String,
  progress: Float,
  color: Color
) {
  Column {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(16.dp))
        Text(title, color = TermTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }
      Text(valueText, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = TerminalMonoFontFamily)
    }
    Spacer(modifier = Modifier.height(2.dp))
    LinearProgressIndicator(
      progress = { progress.coerceIn(0f, 1f) },
      modifier = Modifier
        .fillMaxWidth()
        .height(5.dp)
        .clip(RoundedCornerShape(3.dp)),
      color = color,
      trackColor = TermBorder
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(subtitle, color = TermTextMuted, fontSize = 10.sp)
  }
}

@Composable
private fun EnvVarsDialog(
  onDismiss: () -> Unit
) {
  val env = remember { LinuxEnvironment.getEnvironmentVariables() }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Environment Variables", color = TermTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
    text = {
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .height(260.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        items(env.entries.toList()) { (k, v) ->
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(TermBackground)
              .padding(8.dp)
          ) {
            Text(k, color = TermCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = TerminalMonoFontFamily)
            Text(v, color = TermTextPrimary, fontSize = 10.sp, fontFamily = TerminalMonoFontFamily)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
      }
    },
    containerColor = TermSurface
  )
}

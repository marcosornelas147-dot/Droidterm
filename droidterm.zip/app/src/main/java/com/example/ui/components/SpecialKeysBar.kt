package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.KeyCapActive
import com.example.ui.theme.KeyCapBackground
import com.example.ui.theme.KeyCapBorder
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow

@Composable
fun SpecialKeysBar(
  onKeyPress: (String) -> Unit,
  onCtrlC: () -> Unit,
  onCtrlD: () -> Unit,
  onClear: () -> Unit,
  onOpenAi: () -> Unit,
  modifier: Modifier = Modifier
) {
  var isCtrlActive by remember { mutableStateOf(false) }
  var isAltActive by remember { mutableStateOf(false) }
  val clipboardManager = LocalClipboardManager.current
  val scrollState = rememberScrollState()

  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(TermSurface)
      .border(0.5.dp, TermBorder)
      .padding(vertical = 4.dp, horizontal = 4.dp)
  ) {
    Row(
      modifier = Modifier.horizontalScroll(scrollState),
      horizontalArrangement = Arrangement.spacedBy(4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // ESC
      KeyButton(label = "ESC") {
        onKeyPress("\u001B")
      }

      // TAB
      KeyButton(label = "TAB", textColor = TermYellow) {
        onKeyPress("\t")
      }

      // CTRL Toggle
      KeyButton(
        label = "CTRL",
        isActive = isCtrlActive,
        activeColor = KeyCapActive
      ) {
        isCtrlActive = !isCtrlActive
      }

      // ALT Toggle
      KeyButton(
        label = "ALT",
        isActive = isAltActive,
        activeColor = MaterialTheme.colorScheme.secondary
      ) {
        isAltActive = !isAltActive
      }

      // Interrupt Ctrl+C
      KeyButton(label = "^C", textColor = TermRed) {
        onCtrlC()
      }

      // EOF Ctrl+D
      KeyButton(label = "^D", textColor = TermYellow) {
        onCtrlD()
      }

      // Navigation arrows
      KeyButton(label = "↑") {
        onKeyPress("UP")
      }
      KeyButton(label = "↓") {
        onKeyPress("DOWN")
      }
      KeyButton(label = "←") {
        onKeyPress("LEFT")
      }
      KeyButton(label = "→") {
        onKeyPress("RIGHT")
      }

      // Fast symbols
      val symbols = listOf("|", "~", "/", "-", "_", "$", ":", ";", "&", "\"", "'")
      for (sym in symbols) {
        KeyButton(label = sym) {
          onKeyPress(sym)
        }
      }

      // Paste from clipboard
      KeyButton(label = "PASTE", textColor = TermGreen) {
        clipboardManager.getText()?.text?.let { clipText ->
          onKeyPress(clipText)
        }
      }

      // Clear
      KeyButton(label = "CLEAR") {
        onClear()
      }

      // AI Copilot Quick Key
      KeyButton(
        label = "AI ✨",
        textColor = MaterialTheme.colorScheme.primary,
        borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
      ) {
        onOpenAi()
      }
    }
  }
}

@Composable
private fun KeyButton(
  label: String,
  isActive: Boolean = false,
  activeColor: Color = KeyCapActive,
  textColor: Color = TermTextPrimary,
  borderColor: Color = KeyCapBorder,
  onClick: () -> Unit
) {
  val bg = if (isActive) activeColor.copy(alpha = 0.25f) else KeyCapBackground
  val border = if (isActive) activeColor else borderColor
  val textCol = if (isActive) activeColor else textColor

  Box(
    modifier = Modifier
      .height(34.dp)
      .widthIn(min = 34.dp)
      .clip(RoundedCornerShape(6.dp))
      .background(bg)
      .border(1.dp, border, RoundedCornerShape(6.dp))
      .clickable { onClick() }
      .padding(horizontal = 8.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      color = textCol,
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

package com.example.ui.files

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.environment.LinuxEnvironment
import com.example.core.filesystem.ArchiveHelper
import com.example.core.filesystem.FileEntry
import com.example.core.filesystem.FileManager
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOrange
import com.example.ui.theme.TermPurple
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun FileManagerScreen(
  onOpenInTerminal: (File) -> Unit,
  onRunCommand: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var currentDir by remember { mutableStateOf(LinuxEnvironment.homeDir) }
  var fileEntries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
  var selectedFileForEdit by remember { mutableStateOf<File?>(null) }

  var showNewFileDialog by remember { mutableStateOf(false) }
  var showNewFolderDialog by remember { mutableStateOf(false) }
  var fileToRename by remember { mutableStateOf<File?>(null) }
  var fileToDelete by remember { mutableStateOf<File?>(null) }

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  fun refresh() {
    fileEntries = FileManager.listDirectory(currentDir)
  }

  LaunchedEffect(currentDir) {
    refresh()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(TermBackground)
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Breadcrumbs Header
      BreadcrumbBar(
        currentDir = currentDir,
        onNavigate = { currentDir = it }
      )

      // Quick Access Chips (Home, Projects, Bin, Downloads)
      QuickAccessRow(
        currentDir = currentDir,
        onSelectFolder = { currentDir = it }
      )

      // Actions Ribbon (New File, New Folder, Terminal Here, Refresh)
      ActionsRibbon(
        currentDir = currentDir,
        onNewFile = { showNewFileDialog = true },
        onNewFolder = { showNewFolderDialog = true },
        onTerminalHere = { onOpenInTerminal(currentDir) },
        onRefresh = { refresh() }
      )

      // File List
      if (fileEntries.isEmpty()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          contentAlignment = Alignment.Center
        ) {
          Text("Empty Directory", color = TermTextMuted, fontSize = 14.sp)
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(fileEntries, key = { it.file.absolutePath }) { entry ->
            FileEntryRow(
              entry = entry,
              onClick = {
                if (entry.isDirectory) {
                  currentDir = entry.file
                } else {
                  selectedFileForEdit = entry.file
                }
              },
              onEdit = { selectedFileForEdit = entry.file },
              onOpenTerminal = {
                val targetDir = if (entry.isDirectory) entry.file else entry.file.parentFile ?: currentDir
                onOpenInTerminal(targetDir)
              },
              onRename = { fileToRename = entry.file },
              onDelete = { fileToDelete = entry.file },
              onExtract = {
                scope.launch {
                  val ok = if (entry.name.endsWith(".zip", ignoreCase = true)) {
                    ArchiveHelper.extractZip(entry.file, currentDir) { log ->
                      scope.launch { snackbarHostState.showSnackbar(log) }
                    }
                  } else {
                    ArchiveHelper.extractTar(entry.file, currentDir) { log ->
                      scope.launch { snackbarHostState.showSnackbar(log) }
                    }
                  }
                  if (ok) {
                    snackbarHostState.showSnackbar("Extracted ${entry.name} successfully")
                    refresh()
                  }
                }
              }
            )
          }
        }
      }
    }

    SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))

    // Code Editor Modal
    selectedFileForEdit?.let { file ->
      CodeEditorDialog(
        file = file,
        onRunInTerminal = onRunCommand,
        onDismiss = {
          selectedFileForEdit = null
          refresh()
        }
      )
    }

    // New File Dialog
    if (showNewFileDialog) {
      InputDialog(
        title = "Create New File",
        hint = "script.py / index.html",
        onConfirm = { name ->
          if (name.isNotBlank()) {
            FileManager.createFile(currentDir, name)
            refresh()
          }
          showNewFileDialog = false
        },
        onDismiss = { showNewFileDialog = false }
      )
    }

    // New Folder Dialog
    if (showNewFolderDialog) {
      InputDialog(
        title = "Create New Folder",
        hint = "my_project",
        onConfirm = { name ->
          if (name.isNotBlank()) {
            FileManager.createDirectory(currentDir, name)
            refresh()
          }
          showNewFolderDialog = false
        },
        onDismiss = { showNewFolderDialog = false }
      )
    }

    // Rename Dialog
    fileToRename?.let { file ->
      InputDialog(
        title = "Rename Item",
        hint = file.name,
        initialValue = file.name,
        onConfirm = { newName ->
          if (newName.isNotBlank() && newName != file.name) {
            FileManager.renameItem(file, newName)
            refresh()
          }
          fileToRename = null
        },
        onDismiss = { fileToRename = null }
      )
    }

    // Delete Confirmation
    fileToDelete?.let { file ->
      AlertDialog(
        onDismissRequest = { fileToDelete = null },
        title = { Text("Delete Item", color = TermTextPrimary) },
        text = { Text("Are you sure you want to delete '${file.name}'? This action cannot be undone.", color = TermTextMuted) },
        confirmButton = {
          Button(
            onClick = {
              FileManager.deleteItem(file)
              fileToDelete = null
              refresh()
            },
            colors = ButtonDefaults.buttonColors(containerColor = TermRed)
          ) {
            Text("Delete", color = Color.White)
          }
        },
        dismissButton = {
          TextButton(onClick = { fileToDelete = null }) {
            Text("Cancel", color = TermTextPrimary)
          }
        },
        containerColor = TermSurface
      )
    }
  }
}

@Composable
private fun BreadcrumbBar(
  currentDir: File,
  onNavigate: (File) -> Unit
) {
  val home = LinuxEnvironment.homeDir
  val parts = mutableListOf<Pair<String, File>>()
  var cur: File? = currentDir

  while (cur != null) {
    val label = if (cur.absolutePath == home.absolutePath) "~" else cur.name.ifEmpty { "/" }
    parts.add(0, label to cur)
    if (cur.absolutePath == home.absolutePath) break
    cur = cur.parentFile
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(TermSurface)
      .border(0.5.dp, TermBorder)
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 10.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = Icons.Default.FolderOpen,
      contentDescription = "Folder",
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(16.dp)
    )
    Spacer(modifier = Modifier.width(6.dp))

    parts.forEachIndexed { index, (label, folder) ->
      Text(
        text = label,
        color = if (index == parts.lastIndex) MaterialTheme.colorScheme.primary else TermTextPrimary,
        fontSize = 13.sp,
        fontWeight = if (index == parts.lastIndex) FontWeight.Bold else FontWeight.Medium,
        modifier = Modifier
          .clip(RoundedCornerShape(4.dp))
          .clickable { onNavigate(folder) }
          .padding(horizontal = 4.dp, vertical = 2.dp)
      )
      if (index < parts.lastIndex) {
        Text(" / ", color = TermTextMuted, fontSize = 13.sp)
      }
    }
  }
}

@Composable
private fun QuickAccessRow(
  currentDir: File,
  onSelectFolder: (File) -> Unit
) {
  val shortcuts = remember { FileManager.getQuickAccessFolders() }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(TermBackground)
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 8.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    shortcuts.forEach { (label, folder) ->
      val isSelected = currentDir.absolutePath == folder.absolutePath
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(16.dp))
          .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else TermSurfaceVariant)
          .border(
            1.dp,
            if (isSelected) MaterialTheme.colorScheme.primary else TermBorder,
            RoundedCornerShape(16.dp)
          )
          .clickable { onSelectFolder(folder) }
          .padding(horizontal = 10.dp, vertical = 4.dp)
      ) {
        Text(
          text = label,
          color = if (isSelected) MaterialTheme.colorScheme.primary else TermTextPrimary,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}

@Composable
private fun ActionsRibbon(
  currentDir: File,
  onNewFile: () -> Unit,
  onNewFolder: () -> Unit,
  onTerminalHere: () -> Unit,
  onRefresh: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(TermSurface)
      .border(0.5.dp, TermBorder)
      .padding(horizontal = 8.dp, vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      OutlinedButton(
        onClick = onNewFile,
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TermTextPrimary),
        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(TermBorder)),
        modifier = Modifier.height(30.dp)
      ) {
        Icon(Icons.Default.NoteAdd, contentDescription = "New File", modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("+ File", fontSize = 11.sp)
      }

      OutlinedButton(
        onClick = onNewFolder,
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TermTextPrimary),
        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(TermBorder)),
        modifier = Modifier.height(30.dp)
      ) {
        Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("+ Folder", fontSize = 11.sp)
      }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
      // Terminal Here
      Button(
        onClick = onTerminalHere,
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = TermGreen),
        modifier = Modifier.height(30.dp)
      ) {
        Icon(Icons.Default.Terminal, contentDescription = "Terminal", tint = Color.Black, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("cd here", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }

      IconButton(onClick = onRefresh, modifier = Modifier.size(30.dp)) {
        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TermTextMuted, modifier = Modifier.size(16.dp))
      }
    }
  }
}

@Composable
private fun FileEntryRow(
  entry: FileEntry,
  onClick: () -> Unit,
  onEdit: () -> Unit,
  onOpenTerminal: () -> Unit,
  onRename: () -> Unit,
  onDelete: () -> Unit,
  onExtract: () -> Unit
) {
  var menuExpanded by remember { mutableStateOf(false) }

  val icon = when {
    entry.isDirectory -> Icons.Default.Folder
    entry.isArchive -> Icons.Default.Archive
    else -> Icons.Default.Description
  }

  val iconTint = when {
    entry.isDirectory -> TermYellow
    entry.isArchive -> TermPurple
    entry.extension in listOf("py", "pyc") -> TermCyan
    entry.extension in listOf("js", "json") -> TermYellow
    entry.extension in listOf("html", "htm") -> TermOrange
    entry.extension in listOf("c", "cpp", "h") -> TermGreen
    entry.extension == "sh" -> TermGreen
    else -> TermTextMuted
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(6.dp))
      .background(TermSurfaceVariant)
      .clickable { onClick() }
      .padding(horizontal = 10.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.weight(1f)
    ) {
      Icon(
        imageVector = icon,
        contentDescription = entry.name,
        tint = iconTint,
        modifier = Modifier.size(20.dp)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = entry.name,
          color = TermTextPrimary,
          fontSize = 13.sp,
          fontWeight = if (entry.isDirectory) FontWeight.Bold else FontWeight.Normal
        )
        Text(
          text = "${entry.formattedSize} • ${entry.lastModified}",
          color = TermTextMuted,
          fontSize = 10.sp
        )
      }
    }

    Box {
      IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(24.dp)) {
        Icon(Icons.Default.MoreVert, contentDescription = "Menu", tint = TermTextMuted)
      }

      DropdownMenu(
        expanded = menuExpanded,
        onDismissRequest = { menuExpanded = false },
        modifier = Modifier.background(TermSurface).border(1.dp, TermBorder)
      ) {
        if (!entry.isDirectory) {
          DropdownMenuItem(
            text = { Text("Edit Code", color = TermTextPrimary) },
            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TermCyan) },
            onClick = {
              menuExpanded = false
              onEdit()
            }
          )
        }

        if (entry.isArchive) {
          DropdownMenuItem(
            text = { Text("Extract Archive", color = TermGreen) },
            leadingIcon = { Icon(Icons.Default.Archive, contentDescription = "Extract", tint = TermGreen) },
            onClick = {
              menuExpanded = false
              onExtract()
            }
          )
        }

        DropdownMenuItem(
          text = { Text("Open in Terminal", color = TermTextPrimary) },
          leadingIcon = { Icon(Icons.Default.Terminal, contentDescription = "Terminal", tint = TermYellow) },
          onClick = {
            menuExpanded = false
            onOpenTerminal()
          }
        )

        DropdownMenuItem(
          text = { Text("Rename", color = TermTextPrimary) },
          leadingIcon = { Icon(Icons.Default.Edit, contentDescription = "Rename", tint = TermTextMuted) },
          onClick = {
            menuExpanded = false
            onRename()
          }
        )

        DropdownMenuItem(
          text = { Text("Delete", color = TermRed) },
          leadingIcon = { Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TermRed) },
          onClick = {
            menuExpanded = false
            onDelete()
          }
        )
      }
    }
  }
}

@Composable
private fun InputDialog(
  title: String,
  hint: String,
  initialValue: String = "",
  onConfirm: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var value by remember { mutableStateOf(initialValue) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title, color = TermTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
    text = {
      OutlinedTextField(
        value = value,
        onValueChange = { value = it },
        placeholder = { Text(hint, color = TermTextMuted) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = TermBackground,
          unfocusedContainerColor = TermBackground,
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = TermBorder,
          focusedTextColor = TermTextPrimary,
          unfocusedTextColor = TermTextPrimary
        ),
        modifier = Modifier.fillMaxWidth()
      )
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(value) },
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
      ) {
        Text("Confirm", color = Color.Black, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = TermTextPrimary)
      }
    },
    containerColor = TermSurface
  )
}

package com.example.ui.dev

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.environment.LinuxEnvironment
import com.example.core.filesystem.FileManager
import com.example.core.server.LocalHttpServer
import com.example.ui.theme.TerminalMonoFontFamily
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow
import java.io.File

data class ProjectTemplate(
  val id: String,
  val title: String,
  val language: String,
  val description: String,
  val folderName: String,
  val entryFile: String,
  val defaultContent: String,
  val runCommand: String
)

@Composable
fun DevCenterScreen(
  onOpenTerminalWithCommand: (String) -> Unit,
  onOpenEditor: (File) -> Unit,
  modifier: Modifier = Modifier
) {
  val isServerRunning by LocalHttpServer.isRunning.collectAsState()
  val serverPort by LocalHttpServer.currentPort.collectAsState()
  val serverLogs by LocalHttpServer.logs.collectAsState()

  var showBrowserPreview by remember { mutableStateOf(false) }
  var previewUrl by remember { mutableStateOf("http://127.0.0.1:8080") }

  val defaultServeDir = remember {
    File(LinuxEnvironment.homeDir, "projects/web_app")
  }

  val templates = remember {
    listOf(
      ProjectTemplate(
        id = "web_app",
        title = "HTML5 Responsive Web App",
        language = "HTML / CSS / JS",
        description = "Modern single page web application with responsive styling, button interactions, and local hosting.",
        folderName = "web_app",
        entryFile = "index.html",
        defaultContent = """
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>My DroidTerm Project</title>
            <style>
              body { background: #0d1117; color: #22c55e; font-family: monospace; padding: 20px; }
              button { background: #06b6d4; color: #000; padding: 8px 16px; border: none; border-radius: 4px; font-weight: bold; }
            </style>
          </head>
          <body>
            <h1>DroidTerm Web App</h1>
            <p>Developed entirely on Android.</p>
            <button onclick="alert('Hello Android developer!')">Click Me</button>
          </body>
          </html>
        """.trimIndent(),
        runCommand = "serve 8080"
      ),
      ProjectTemplate(
        id = "python_calc",
        title = "Python Data Analysis Script",
        language = "Python 3",
        description = "Data manipulation and calculations script with statistics, arrays, and formatted CLI output.",
        folderName = "python_demo",
        entryFile = "main.py",
        defaultContent = """
          import math
          import time

          print("=== DroidTerm Python Data Processor ===")
          data = [12, 45, 67, 89, 23, 56, 78, 90, 101, 34]
          print(f"Dataset: {data}")
          print(f"Count: {len(data)}, Sum: {sum(data)}, Average: {sum(data)/len(data):.2f}")
          print(f"Max: {max(data)}, Min: {min(data)}")
          print(f"Standard Dev: {math.sqrt(sum((x - sum(data)/len(data))**2 for x in data)/len(data)):.2f}")
          print("Execution completed at: " + time.strftime("%H:%M:%S"))
        """.trimIndent(),
        runCommand = "python3 main.py"
      ),
      ProjectTemplate(
        id = "node_server",
        title = "Node.js REST API Server",
        language = "Node.js",
        description = "Lightweight HTTP microservice with JSON endpoints, status routes, and request logger.",
        folderName = "node_api",
        entryFile = "server.js",
        defaultContent = """
          const http = require('http');
          const PORT = 3000;

          const server = http.createServer((req, res) => {
            if (req.url === '/api/status') {
              res.writeHead(200, { 'Content-Type': 'application/json' });
              return res.end(JSON.stringify({ status: 'online', uptime: process.uptime(), time: new Date() }));
            }
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end('DroidTerm Node.js API is alive on port ' + PORT);
          });

          server.listen(PORT, () => {
            console.log('API Server running on http://127.0.0.1:' + PORT);
          });
        """.trimIndent(),
        runCommand = "node server.js"
      ),
      ProjectTemplate(
        id = "c_math",
        title = "C High Performance Benchmark",
        language = "C / Clang",
        description = "Fast native C algorithm with prime number calculation and loop profiling.",
        folderName = "c_math",
        entryFile = "main.c",
        defaultContent = """
          #include <stdio.h>
          #include <stdbool.h>

          bool is_prime(int n) {
              if (n <= 1) return false;
              for (int i = 2; i * i <= n; i++) {
                  if (n % i == 0) return false;
              }
              return true;
          }

          int main() {
              printf("Calculating prime numbers up to 50 on Android:\n");
              int count = 0;
              for (int i = 2; i <= 50; i++) {
                  if (is_prime(i)) {
                      printf("%d ", i);
                      count++;
                  }
              }
              printf("\nTotal primes found: %d\n", count);
              return 0;
          }
        """.trimIndent(),
        runCommand = "clang main.c -o run && ./run"
      ),
      ProjectTemplate(
        id = "bash_backup",
        title = "Shell Automation & Backup",
        language = "Bash / POSIX sh",
        description = "Automated file backup, disk cleanup, and project archiver script.",
        folderName = "automation",
        entryFile = "backup.sh",
        defaultContent = """
          #!/system/bin/sh
          echo "[+] Starting automated backup..."
          BACKUP_DIR="${'$'}HOME/backup_$(date +%Y%m%d_%H%M%S)"
          mkdir -p "${'$'}BACKUP_DIR"
          echo "[+] Copying project files to ${'$'}BACKUP_DIR..."
          cp -r "${'$'}HOME/projects" "${'$'}BACKUP_DIR" 2>/dev/null || true
          echo "[✔] Backup completed successfully in: ${'$'}BACKUP_DIR"
          ls -lah "${'$'}BACKUP_DIR"
        """.trimIndent(),
        runCommand = "sh backup.sh"
      )
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(TermBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Local HTTP Web Server Controller Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Dns,
                contentDescription = "Server",
                tint = if (isServerRunning) TermGreen else TermTextMuted,
                modifier = Modifier.size(20.dp)
              )
              Text(
                text = "Local HTTP Server",
                color = TermTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
              )
            }

            // Status Badge
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(if (isServerRunning) TermGreen else TermRed)
              )
              Text(
                text = if (isServerRunning) "PORT $serverPort ONLINE" else "STOPPED",
                color = if (isServerRunning) TermGreen else TermTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Host static websites, APIs, or files directly from your Android phone on localhost.",
            color = TermTextMuted,
            fontSize = 12.sp
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Server Action Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            if (isServerRunning) {
              Button(
                onClick = { LocalHttpServer.stop() },
                colors = ButtonDefaults.buttonColors(containerColor = TermRed),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Stop Server", color = Color.White, fontWeight = FontWeight.Bold)
              }

              Button(
                onClick = {
                  previewUrl = "http://127.0.0.1:$serverPort"
                  showBrowserPreview = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.OpenInBrowser, contentDescription = "Preview", tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Live Preview", color = Color.Black, fontWeight = FontWeight.Bold)
              }
            } else {
              Button(
                onClick = {
                  val serveDir = if (defaultServeDir.exists()) defaultServeDir else LinuxEnvironment.homeDir
                  LocalHttpServer.start(8080, serveDir)
                },
                colors = ButtonDefaults.buttonColors(containerColor = TermGreen),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Start", tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Start Server (Port 8080)", color = Color.Black, fontWeight = FontWeight.Bold)
              }
            }
          }

          // Live Server Logs
          if (serverLogs.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 100.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(TermBackground)
                .border(0.5.dp, TermBorder)
                .padding(6.dp)
            ) {
              serverLogs.takeLast(4).forEach { log ->
                Text(
                  text = log,
                  color = TermTextPrimary,
                  fontSize = 10.sp,
                  fontFamily = TerminalMonoFontFamily
                )
              }
            }
          }
        }
      }
    }

    // 2. Starter Project Generator Section Header
    item {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(Icons.Default.RocketLaunch, contentDescription = "Projects", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Text(
          text = "Starter Projects & Code Templates",
          color = TermTextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Template Cards
    items(templates, key = { it.id }) { tpl ->
      TemplateCard(
        template = tpl,
        onCreateAndOpen = {
          val projectsDir = File(LinuxEnvironment.homeDir, "projects").apply { mkdirs() }
          val targetDir = File(projectsDir, tpl.folderName).apply { mkdirs() }
          val targetFile = File(targetDir, tpl.entryFile)
          if (!targetFile.exists()) {
            targetFile.writeText(tpl.defaultContent)
          }
          onOpenEditor(targetFile)
        },
        onRunInTerminal = {
          val projectsDir = File(LinuxEnvironment.homeDir, "projects").apply { mkdirs() }
          val targetDir = File(projectsDir, tpl.folderName).apply { mkdirs() }
          val targetFile = File(targetDir, tpl.entryFile)
          if (!targetFile.exists()) {
            targetFile.writeText(tpl.defaultContent)
          }
          onOpenTerminalWithCommand("cd \"${targetDir.absolutePath}\" && ${tpl.runCommand}")
        }
      )
    }
  }

  // WebView in-app Browser Preview
  if (showBrowserPreview) {
    WebViewPreviewDialog(
      url = previewUrl,
      onDismiss = { showBrowserPreview = false }
    )
  }
}

@Composable
private fun TemplateCard(
  template: ProjectTemplate,
  onCreateAndOpen: () -> Unit,
  onRunInTerminal: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(TermSurface)
      .border(1.dp, TermBorder, RoundedCornerShape(8.dp))
      .padding(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = template.title,
        color = TermTextPrimary,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold
      )
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(4.dp))
          .background(TermSurfaceVariant)
          .border(0.5.dp, TermBorder, RoundedCornerShape(4.dp))
          .padding(horizontal = 6.dp, vertical = 2.dp)
      ) {
        Text(template.language, color = TermCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = template.description,
      color = TermTextMuted,
      fontSize = 11.sp,
      lineHeight = 16.sp
    )

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      OutlinedButton(
        onClick = onCreateAndOpen,
        shape = RoundedCornerShape(6.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary)),
        modifier = Modifier.weight(1f).height(32.dp)
      ) {
        Icon(Icons.Default.Code, contentDescription = "Edit", modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Edit Code", fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }

      Button(
        onClick = onRunInTerminal,
        colors = ButtonDefaults.buttonColors(containerColor = TermGreen),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.weight(1f).height(32.dp)
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = Color.Black, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Run Project", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.ai.TerminalAiAssistant
import com.example.core.environment.LinuxEnvironment
import com.example.ui.theme.TerminalMonoFontFamily
import com.example.ui.theme.TerminalThemeMode
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow

@Composable
fun SettingsScreen(
  currentTheme: TerminalThemeMode,
  onThemeChange: (TerminalThemeMode) -> Unit,
  fontSizeSp: Int,
  onFontSizeChange: (Int) -> Unit,
  onBackupEnvironment: () -> Unit,
  modifier: Modifier = Modifier
) {
  var sliderFontSize by remember { mutableFloatStateOf(fontSizeSp.toFloat()) }
  var useExternalApi by remember { mutableStateOf(TerminalAiAssistant.useExternalApi) }
  var apiUrl by remember { mutableStateOf(TerminalAiAssistant.customApiUrl) }
  var apiKey by remember { mutableStateOf(TerminalAiAssistant.customApiKey) }
  var modelName by remember { mutableStateOf(TerminalAiAssistant.customModel) }
  var savedApiMessage by remember { mutableStateOf<String?>(null) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(TermBackground)
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Theme Selection
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Palette, contentDescription = "Themes", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text("Terminal Theme & Colors", color = TermTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(10.dp))

          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalThemeMode.entries.forEach { theme ->
              val isSelected = theme == currentTheme
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else TermSurfaceVariant)
                  .border(
                    1.dp,
                    if (isSelected) MaterialTheme.colorScheme.primary else TermBorder,
                    RoundedCornerShape(6.dp)
                  )
                  .clickable { onThemeChange(theme) }
                  .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .size(12.dp)
                      .clip(CircleShape)
                      .background(theme.primaryColor)
                  )
                  Text(
                    text = theme.displayName,
                    color = TermTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                  )
                }

                if (isSelected) {
                  Text("ACTIVE", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }

    // 2. Font Size
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.FormatSize, contentDescription = "Font", tint = TermYellow, modifier = Modifier.size(18.dp))
            Text("Terminal Font Size (${fontSizeSp}sp)", color = TermTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(6.dp))

          Slider(
            value = sliderFontSize,
            onValueChange = {
              sliderFontSize = it
              onFontSizeChange(it.toInt())
            },
            valueRange = 10f..18f,
            steps = 7,
            colors = SliderDefaults.colors(
              thumbColor = MaterialTheme.colorScheme.primary,
              activeTrackColor = MaterialTheme.colorScheme.primary,
              inactiveTrackColor = TermBorder
            )
          )

          // Preview text
          Text(
            text = "droid@android:~$ python3 -c \"print('DroidTerm Mono')\"",
            color = TermGreen,
            fontSize = fontSizeSp.sp,
            fontFamily = TerminalMonoFontFamily
          )
        }
      }
    }

    // 3. AI Copilot External API Configuration
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = TermCyan, modifier = Modifier.size(18.dp))
              Text("External AI Provider (Optional)", color = TermTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            Switch(
              checked = useExternalApi,
              onCheckedChange = {
                useExternalApi = it
                TerminalAiAssistant.useExternalApi = it
              },
              colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                uncheckedTrackColor = TermBorder
              )
            )
          }

          Text(
            text = "By default, DroidTerm uses 100% offline intelligence. Enable to connect to your custom OpenAI / Gemini API endpoint.",
            color = TermTextMuted,
            fontSize = 11.sp
          )

          if (useExternalApi) {
            Spacer(modifier = Modifier.height(10.dp))

            // API Endpoint URL
            OutlinedTextField(
              value = apiUrl,
              onValueChange = { apiUrl = it },
              label = { Text("API Endpoint URL", fontSize = 11.sp) },
              placeholder = { Text("https://api.openai.com/v1/chat/completions", fontSize = 11.sp) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TermBackground,
                unfocusedContainerColor = TermBackground,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = TermBorder,
                focusedTextColor = TermTextPrimary,
                unfocusedTextColor = TermTextPrimary
              )
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Model Name
            OutlinedTextField(
              value = modelName,
              onValueChange = { modelName = it },
              label = { Text("Model Name", fontSize = 11.sp) },
              placeholder = { Text("gpt-4o-mini", fontSize = 11.sp) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TermBackground,
                unfocusedContainerColor = TermBackground,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = TermBorder,
                focusedTextColor = TermTextPrimary,
                unfocusedTextColor = TermTextPrimary
              )
            )

            Spacer(modifier = Modifier.height(6.dp))

            // API Key
            OutlinedTextField(
              value = apiKey,
              onValueChange = { apiKey = it },
              label = { Text("API Key (Stored locally in memory)", fontSize = 11.sp) },
              placeholder = { Text("sk-...", fontSize = 11.sp) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TermBackground,
                unfocusedContainerColor = TermBackground,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = TermBorder,
                focusedTextColor = TermTextPrimary,
                unfocusedTextColor = TermTextPrimary
              )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
              onClick = {
                TerminalAiAssistant.customApiUrl = apiUrl.trim()
                TerminalAiAssistant.customApiKey = apiKey.trim()
                TerminalAiAssistant.customModel = modelName.trim().ifEmpty { "gpt-4o-mini" }
                TerminalAiAssistant.useExternalApi = true
                savedApiMessage = "API Credentials updated!"
              },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("Save AI Settings", color = Color.Black, fontWeight = FontWeight.Bold)
            }

            savedApiMessage?.let { msg ->
              Spacer(modifier = Modifier.height(4.dp))
              Text(msg, color = TermGreen, fontSize = 11.sp)
            }
          }
        }
      }
    }

    // 4. Environment Backup
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Backup, contentDescription = "Backup", tint = TermGreen, modifier = Modifier.size(18.dp))
            Text("Backup & Environment Storage", color = TermTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Export your entire \$HOME projects, scripts, and installed packages as a tar archive.",
            color = TermTextMuted,
            fontSize = 12.sp
          )

          Spacer(modifier = Modifier.height(10.dp))

          Button(
            onClick = onBackupEnvironment,
            colors = ButtonDefaults.buttonColors(containerColor = TermGreen),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.Backup, contentDescription = "Backup", tint = Color.Black, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Backup \$HOME to Archive", color = Color.Black, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 5. About DroidTerm
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = TermSurface),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TermBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Info, contentDescription = "About", tint = TermCyan, modifier = Modifier.size(18.dp))
            Text("About DroidTerm", color = TermTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text("Version: 2.4.0 (Production Build)", color = TermTextPrimary, fontSize = 12.sp)
          Text("Target Architecture: ARM64, ARM32 (armeabi-v7a), x86_64", color = TermTextMuted, fontSize = 11.sp)
          Text("Shell: POSIX /system/bin/sh + Toybox", color = TermTextMuted, fontSize = 11.sp)
          Text("Root Required: NO (Runs natively in userspace)", color = TermGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

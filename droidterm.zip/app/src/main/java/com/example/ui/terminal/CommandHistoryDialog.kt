package com.example.ui.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandHistoryDialog(
  history: List<String>,
  onSelectCommand: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  val filteredHistory = remember(history, searchQuery) {
    if (searchQuery.isBlank()) {
      history.asReversed()
    } else {
      history.asReversed().filter { it.contains(searchQuery, ignoreCase = true) }
    }
  }

  BasicAlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier
      .fillMaxWidth(0.92f)
      .clip(RoundedCornerShape(12.dp))
      .background(TermSurface)
      .border(1.dp, TermBorder, RoundedCornerShape(12.dp))
  ) {
    Column(
      modifier = Modifier.padding(16.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.History,
            contentDescription = "History",
            tint = TermYellow,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = "Command History",
            color = TermTextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
        }
        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = TermTextMuted)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Search Box
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Filter past commands...", color = TermTextMuted, fontSize = 13.sp) },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = "Search", tint = TermTextMuted, modifier = Modifier.size(18.dp))
        },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = TermBackground,
          unfocusedContainerColor = TermBackground,
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = TermBorder,
          focusedTextColor = TermTextPrimary,
          unfocusedTextColor = TermTextPrimary
        )
      )

      Spacer(modifier = Modifier.height(12.dp))

      // History List
      if (filteredHistory.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("No commands in history", color = TermTextMuted, fontSize = 13.sp)
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 300.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(filteredHistory) { cmd ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(TermSurfaceVariant)
                .clickable {
                  onSelectCommand(cmd)
                  onDismiss()
                }
                .padding(horizontal = 10.dp, vertical = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = cmd,
                color = TermTextPrimary,
                fontSize = 13.sp,
                modifier = Modifier.weight(1f)
              )
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Execute",
                tint = TermGreen,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    }
  }
}

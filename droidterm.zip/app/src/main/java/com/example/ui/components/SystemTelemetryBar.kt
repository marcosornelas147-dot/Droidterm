package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.system.SystemMonitor
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow

@Composable
fun SystemTelemetryBar(
  onOpenSystem: () -> Unit,
  modifier: Modifier = Modifier
) {
  val cpuUsage by SystemMonitor.cpuUsage.collectAsState()
  val memory by SystemMonitor.memoryMetrics.collectAsState()
  val storage by SystemMonitor.storageMetrics.collectAsState()

  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(TermSurface)
      .clip(RoundedCornerShape(0.dp))
      .clickable { onOpenSystem() }
      .padding(horizontal = 12.dp, vertical = 6.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // CPU Gauge
      TelemetryItem(
        icon = Icons.Default.Speed,
        label = "CPU",
        value = "$cpuUsage%",
        progress = cpuUsage / 100f,
        color = when {
          cpuUsage > 80 -> TermRed
          cpuUsage > 50 -> TermYellow
          else -> TermGreen
        }
      )

      // RAM Gauge
      TelemetryItem(
        icon = Icons.Default.Memory,
        label = "RAM",
        value = "${memory.usedMb}/${memory.totalMb} MB",
        progress = memory.percentageUsed,
        color = when {
          memory.percentageUsed > 0.85f -> TermRed
          memory.percentageUsed > 0.65f -> TermYellow
          else -> MaterialTheme.colorScheme.primary
        }
      )

      // Storage Gauge
      TelemetryItem(
        icon = Icons.Default.Storage,
        label = "DISK",
        value = String.format("%.1f GB free", storage.freeGb),
        progress = storage.percentageUsed,
        color = MaterialTheme.colorScheme.secondary
      )
    }
  }
}

@Composable
private fun TelemetryItem(
  icon: ImageVector,
  label: String,
  value: String,
  progress: Float,
  color: Color
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = color,
      modifier = Modifier.size(14.dp)
    )
    Column {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text(
          text = label,
          color = TermTextMuted,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = value,
          color = TermTextPrimary,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium
        )
      }
      Spacer(modifier = Modifier.height(2.dp))
      LinearProgressIndicator(
        progress = { progress.coerceIn(0f, 1f) },
        modifier = Modifier
          .width(70.dp)
          .height(3.dp)
          .clip(RoundedCornerShape(2.dp)),
        color = color,
        trackColor = TermBorder
      )
    }
  }
}

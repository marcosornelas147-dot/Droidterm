package com.example.ui.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.ai.TerminalAiAssistant
import com.example.ui.theme.TerminalMonoFontFamily
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import com.example.ui.theme.TermYellow
import kotlinx.coroutines.launch

@Composable
fun AiCopilotDialog(
  terminalContext: String = "",
  onRunCommand: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var promptInput by remember { mutableStateOf("") }
  var responseText by remember {
    mutableStateOf(
      """
      Hello! I am DroidTerm Copilot.
      I can help explain commands, generate automation scripts, diagnose errors, or suggest packages.
      
      You are running in Offline Mode (zero internet required).
      External AI providers can be configured in the Settings tab.
      """.trimIndent()
    )
  }
  var isLoading by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()

  val quickPrompts = listOf(
    "Explain 'tar -czvf'",
    "Fix 'Permission denied'",
    "How to search text in files",
    "Create Python file and run it",
    "Start local web server",
    "Check open ports"
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .imePadding(),
      color = TermBackground
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TermSurface)
            .border(0.5.dp, TermBorder)
            .padding(horizontal = 12.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = "AI Copilot",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp)
            )
            Column {
              Text(
                text = "Terminal AI Copilot",
                color = TermTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = if (TerminalAiAssistant.useExternalApi) "Connected to API (${TerminalAiAssistant.customModel})" else "Offline Expert Knowledge",
                color = TermGreen,
                fontSize = 10.sp
              )
            }
          }

          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TermTextPrimary)
          }
        }

        // Quick prompts row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TermSurfaceVariant)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          quickPrompts.forEach { q ->
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(TermSurface)
                .border(0.5.dp, TermBorder, RoundedCornerShape(12.dp))
                .clickable {
                  promptInput = q
                  isLoading = true
                  scope.launch {
                    responseText = TerminalAiAssistant.askAssistant(q, terminalContext)
                    isLoading = false
                  }
                }
                .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Text(q, color = TermTextPrimary, fontSize = 11.sp)
            }
          }
        }

        // Response Display
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(12.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(TermSurface)
            .border(1.dp, TermBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
        ) {
          if (isLoading) {
            Row(
              modifier = Modifier.align(Alignment.Center),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.primary, strokeWidth = 2.dp)
              Text("Thinking...", color = TermTextMuted, fontSize = 13.sp)
            }
          } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
              item {
                Text(
                  text = responseText,
                  color = TermTextPrimary,
                  fontSize = 13.sp,
                  lineHeight = 18.sp,
                  fontFamily = TerminalMonoFontFamily
                )
              }
            }
          }
        }

        // Input & Send Row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TermSurface)
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = promptInput,
            onValueChange = { promptInput = it },
            placeholder = { Text("Ask Copilot or request a script...", color = TermTextMuted, fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier.weight(1f),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = TermBackground,
              unfocusedContainerColor = TermBackground,
              focusedBorderColor = MaterialTheme.colorScheme.primary,
              unfocusedBorderColor = TermBorder,
              focusedTextColor = TermTextPrimary,
              unfocusedTextColor = TermTextPrimary
            )
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = {
              if (promptInput.isNotBlank()) {
                val q = promptInput
                promptInput = ""
                isLoading = true
                scope.launch {
                  responseText = TerminalAiAssistant.askAssistant(q, terminalContext)
                  isLoading = false
                }
              }
            },
            modifier = Modifier
              .size(42.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(MaterialTheme.colorScheme.primary)
          ) {
            Icon(Icons.Default.Send, contentDescription = "Ask", tint = Color.Black, modifier = Modifier.size(18.dp))
          }
        }
      }
    }
  }
}

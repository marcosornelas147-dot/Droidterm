package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DroidTerm Color Palette - Hacker / Terminal aesthetics
val TermBlack = Color(0xFF0A0E14)
val TermBackground = Color(0xFF0D1117)
val TermSurface = Color(0xFF161B22)
val TermSurfaceVariant = Color(0xFF21262D)
val TermBorder = Color(0xFF30363D)

// Neon & Accents
val TermGreen = Color(0xFF22C55E)       // Matrix electric green
val TermCyan = Color(0xFF06B6D4)        // Cyberpunk cyan
val TermBlue = Color(0xFF38BDF8)        // Terminal sky blue
val TermYellow = Color(0xFFFACC15)      // Warning / command prompt
val TermOrange = Color(0xFFFB923C)      // Accent
val TermRed = Color(0xFFEF4444)         // Error / exit code != 0
val TermPurple = Color(0xFFA855F7)      // Special / Git
val TermPink = Color(0xFFEC4899)        // Accent

// Text shades
val TermTextPrimary = Color(0xFFE6EDF3)
val TermTextSecondary = Color(0xFF8B949E)
val TermTextMuted = Color(0xFF484F58)
val TermPromptUser = Color(0xFF38BDF8)
val TermPromptHost = Color(0xFF22C55E)
val TermPromptPath = Color(0xFFFACC15)

// Virtual keyboard bar colors
val KeyCapBackground = Color(0xFF1F242C)
val KeyCapBorder = Color(0xFF333B47)
val KeyCapPressed = Color(0xFF2E3642)
val KeyCapActive = Color(0xFF06B6D4)

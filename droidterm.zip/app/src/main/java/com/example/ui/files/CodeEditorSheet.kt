package com.example.ui.files

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.filesystem.FileManager
import com.example.ui.theme.TerminalMonoFontFamily
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermCyan
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import java.io.File

@Composable
fun CodeEditorDialog(
  file: File,
  onRunInTerminal: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var content by remember { mutableStateOf("") }
  var isSaved by remember { mutableStateOf(true) }
  var saveMessage by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(file) {
    content = FileManager.readFile(file)
    isSaved = true
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .imePadding(),
      color = TermBackground
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Editor Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(TermSurface)
            .border(0.5.dp, TermBorder)
            .padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = TermTextPrimary)
            }
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = file.name,
                  color = TermTextPrimary,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold
                )
                if (!isSaved) {
                  Text(
                    text = " *",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
              Text(
                text = "${content.lines().size} lines • ${file.length()} bytes",
                color = TermTextMuted,
                fontSize = 11.sp
              )
            }
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Run Button
            OutlinedButton(
              onClick = {
                // Auto-save before running
                FileManager.saveFile(file, content)
                isSaved = true
                val command = when (file.extension.lowercase()) {
                  "py" -> "python3 ${file.name}"
                  "js" -> "node ${file.name}"
                  "sh" -> "sh ${file.name}"
                  "c" -> "clang ${file.name} -o run && ./run"
                  "cpp" -> "clang++ ${file.name} -o run && ./run"
                  "html" -> "serve 8080"
                  else -> "cat ${file.name}"
                }
                onRunInTerminal("cd \"${file.parentFile?.absolutePath ?: "~"}\" && $command")
                onDismiss()
              },
              colors = ButtonDefaults.outlinedButtonColors(contentColor = TermGreen),
              border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(TermGreen)),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.height(34.dp)
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = "Run", modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Run", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            // Save Button
            Button(
              onClick = {
                val ok = FileManager.saveFile(file, content)
                if (ok) {
                  isSaved = true
                  saveMessage = "Saved!"
                } else {
                  saveMessage = "Failed to save"
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.height(34.dp)
            ) {
              Icon(Icons.Default.Save, contentDescription = "Save", tint = Color.Black, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Save", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        // Code Editor Body with Line Numbers Gutter
        val verticalScrollState = rememberScrollState()
        val horizontalScrollState = rememberScrollState()
        val linesCount = content.lines().size.coerceAtLeast(1)

        Row(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .background(TermBackground)
        ) {
          // Line Numbers Gutter
          Column(
            modifier = Modifier
              .width(44.dp)
              .fillMaxHeight()
              .background(TermSurfaceVariant)
              .border(0.5.dp, TermBorder)
              .verticalScroll(verticalScrollState)
              .padding(vertical = 8.dp),
            horizontalAlignment = Alignment.End
          ) {
            for (i in 1..linesCount) {
              Text(
                text = "$i ",
                color = TermTextMuted,
                fontSize = 12.sp,
                fontFamily = TerminalMonoFontFamily,
                lineHeight = 18.sp,
                modifier = Modifier.padding(end = 6.dp)
              )
            }
          }

          // Editable Code Input
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight()
              .verticalScroll(verticalScrollState)
              .horizontalScroll(horizontalScrollState)
              .padding(8.dp)
          ) {
            BasicTextField(
              value = content,
              onValueChange = {
                content = it
                isSaved = false
              },
              textStyle = TextStyle(
                fontFamily = TerminalMonoFontFamily,
                color = TermTextPrimary,
                fontSize = 13.sp,
                lineHeight = 18.sp
              ),
              cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
              modifier = Modifier.fillMaxSize()
            )
          }
        }
      }
    }
  }
}

package com.example.core.filesystem

import android.os.Environment
import com.example.core.environment.LinuxEnvironment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FileEntry(
  val file: File,
  val name: String,
  val isDirectory: Boolean,
  val sizeBytes: Long,
  val formattedSize: String,
  val lastModified: String,
  val extension: String,
  val isArchive: Boolean
)

object FileManager {

  fun listDirectory(directory: File): List<FileEntry> {
    if (!directory.exists() || !directory.isDirectory) return emptyList()

    val files = directory.listFiles() ?: return emptyList()
    val dateFormat = SimpleDateFormat("MMM dd HH:mm", Locale.US)

    return files.map { file ->
      val isDir = file.isDirectory
      val size = if (isDir) 0L else file.length()
      val ext = file.extension.lowercase()
      val isArch = ext in listOf("zip", "tar", "gz", "tgz", "bz2", "xz")

      FileEntry(
        file = file,
        name = file.name,
        isDirectory = isDir,
        sizeBytes = size,
        formattedSize = if (isDir) "${(file.listFiles()?.size ?: 0)} items" else formatSize(size),
        lastModified = dateFormat.format(Date(file.lastModified())),
        extension = ext,
        isArchive = isArch
      )
    }.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
  }

  fun createFile(parentDir: File, name: String, initialContent: String = ""): Boolean {
    return try {
      val file = File(parentDir, name)
      if (file.exists()) return false
      file.writeText(initialContent)
      true
    } catch (_: Exception) {
      false
    }
  }

  fun createDirectory(parentDir: File, name: String): Boolean {
    return try {
      val dir = File(parentDir, name)
      dir.mkdirs()
    } catch (_: Exception) {
      false
    }
  }

  fun deleteItem(file: File): Boolean {
    return try {
      if (file.isDirectory) {
        file.deleteRecursively()
      } else {
        file.delete()
      }
    } catch (_: Exception) {
      false
    }
  }

  fun renameItem(file: File, newName: String): Boolean {
    return try {
      val target = File(file.parentFile, newName)
      file.renameTo(target)
    } catch (_: Exception) {
      false
    }
  }

  fun readFile(file: File): String {
    return try {
      file.readText()
    } catch (e: Exception) {
      "// Error reading file: ${e.message}"
    }
  }

  fun saveFile(file: File, content: String): Boolean {
    return try {
      file.writeText(content)
      true
    } catch (_: Exception) {
      false
    }
  }

  fun getQuickAccessFolders(): List<Pair<String, File>> {
    val folders = mutableListOf(
      "Home (~)" to LinuxEnvironment.homeDir,
      "Projects" to File(LinuxEnvironment.homeDir, "projects").apply { mkdirs() },
      "Binaries" to LinuxEnvironment.binDir,
      "Usr Prefix" to LinuxEnvironment.usrDir
    )

    // Android external storage Downloads / Documents
    try {
      val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
      if (downloads != null && downloads.exists()) {
        folders.add("Downloads" to downloads)
      }
      val documents = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
      if (documents != null && documents.exists()) {
        folders.add("Documents" to documents)
      }
    } catch (_: Exception) {}

    return folders
  }

  private fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
    val gb = mb / 1024.0
    return String.format(Locale.US, "%.1f GB", gb)
  }
}

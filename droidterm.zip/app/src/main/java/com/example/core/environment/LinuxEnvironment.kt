package com.example.core.environment

import android.content.Context
import java.io.File

object LinuxEnvironment {

  private var isInitialized = false

  lateinit var homeDir: File
    private set
  lateinit var usrDir: File
    private set
  lateinit var binDir: File
    private set
  lateinit var etcDir: File
    private set
  lateinit var libDir: File
    private set
  lateinit var tmpDir: File
    private set
  lateinit var pkgDbDir: File
    private set

  fun init(context: Context) {
    if (isInitialized) return

    val baseDir = context.filesDir
    homeDir = File(baseDir, "home").apply { mkdirs() }
    usrDir = File(baseDir, "usr").apply { mkdirs() }
    binDir = File(usrDir, "bin").apply { mkdirs() }
    etcDir = File(usrDir, "etc").apply { mkdirs() }
    libDir = File(usrDir, "lib").apply { mkdirs() }
    tmpDir = File(baseDir, "tmp").apply { mkdirs() }
    pkgDbDir = File(usrDir, "var/lib/pkg").apply { mkdirs() }

    // Bootstrap default config files
    createDefaultConfigFiles()

    // Bootstrap core binaries & utility scripts
    BuiltinToolsBootstrap.bootstrap(binDir, homeDir, etcDir)

    // Pre-install starter templates in $HOME
    createStarterProjects(homeDir)

    isInitialized = true
  }

  fun getEnvironmentVariables(customVars: Map<String, String> = emptyMap()): Map<String, String> {
    val defaultPath = "${binDir.absolutePath}:${homeDir.absolutePath}/bin:/system/bin:/system/xbin:/vendor/bin"
    val defaultLd = "${libDir.absolutePath}:/system/lib64:/system/lib"

    val vars = mutableMapOf(
      "HOME" to homeDir.absolutePath,
      "PREFIX" to usrDir.absolutePath,
      "PATH" to defaultPath,
      "LD_LIBRARY_PATH" to defaultLd,
      "TMPDIR" to tmpDir.absolutePath,
      "TERM" to "xterm-256color",
      "COLORTERM" to "truecolor",
      "SHELL" to "/system/bin/sh",
      "USER" to "droid",
      "LOGNAME" to "droid",
      "HOSTNAME" to "droidterm-android",
      "LANG" to "en_US.UTF-8"
    )

    vars.putAll(customVars)
    return vars
  }

  private fun createDefaultConfigFiles() {
    val bashrc = File(homeDir, ".bashrc")
    if (!bashrc.exists()) {
      bashrc.writeText(
        """
        # DroidTerm Environment configuration
        export PS1="\[\033[01;32m\]droid@android\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]$ "
        alias ll="ls -la"
        alias la="ls -A"
        alias l="ls -CF"
        alias cls="clear"
        alias update="pkg update && pkg upgrade"
        """.trimIndent()
      )
    }

    val motd = File(etcDir, "motd")
    if (!motd.exists()) {
      motd.writeText(
        """
         ____            _     _ _____                     
        |  _ \ _ __ ___ (_) __| |_   _|__ _ __ _ __ ___  
        | | | | '__/ _ \| |/ _` | | |/ _ \ '__| '_ ` _ \ 
        | |_| | | | (_) | | (_| | | |  __/ |  | | | | | |
        |____/|_|  \___/|_|\__,_| |_|\___|_|  |_| |_| |_|
        
        Welcome to DroidTerm Linux Environment for Android!
        • Type 'help' or 'droid-help' for documentation
        • Type 'pkg list' to explore installable developer packages
        • Type 'neofetch' to view hardware & OS telemetry
        • Real Linux process execution without root required
        """.trimIndent()
      )
    }
  }

  private fun createStarterProjects(home: File) {
    val projectsDir = File(home, "projects").apply { mkdirs() }

    // Python starter project
    val pythonDir = File(projectsDir, "python_demo").apply { mkdirs() }
    val pyFile = File(pythonDir, "main.py")
    if (!pyFile.exists()) {
      pyFile.writeText(
        """
        #!/usr/bin/env python3
        # DroidTerm Python Example
        import sys
        import platform
        import time

        print("=== Welcome to Python on DroidTerm ===")
        print(f"Python: {platform.python_version()}")
        print(f"Platform: {platform.platform()}")
        print(f"System Time: {time.strftime('%Y-%m-%d %H:%M:%S')}")

        numbers = [x * x for x in range(1, 11)]
        print(f"Square numbers calculation: {numbers}")
        print("Calculation complete! Happy coding on Android!")
        """.trimIndent()
      )
    }

    // Node.js starter project
    val nodeDir = File(projectsDir, "node_server").apply { mkdirs() }
    val jsFile = File(nodeDir, "server.js")
    if (!jsFile.exists()) {
      jsFile.writeText(
        """
        // DroidTerm Node.js Web Server Example
        const http = require('http');
        const PORT = 8080;

        const server = http.createServer((req, res) => {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(`
            <!DOCTYPE html>
            <html>
              <head><title>DroidTerm Local Server</title></head>
              <body style="font-family: monospace; background:#0d1117; color:#22c55e; padding:40px;">
                <h1>🚀 DroidTerm Local Server Active!</h1>
                <p>Served locally from your Android device.</p>
                <p>Node.js runtime environment is operational.</p>
              </body>
            </html>
          `);
        });

        server.listen(PORT, () => {
          console.log(`[DroidTerm] Server running on http://127.0.0.1:${'$'}{PORT}`);
        });
        """.trimIndent()
      )
    }

    // HTML / Web starter project
    val webDir = File(projectsDir, "web_app").apply { mkdirs() }
    val htmlFile = File(webDir, "index.html")
    if (!htmlFile.exists()) {
      htmlFile.writeText(
        """
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>DroidTerm Web Project</title>
          <style>
            body {
              margin: 0;
              padding: 24px;
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace;
              background-color: #0d1117;
              color: #e6edf3;
            }
            .card {
              background: #161b22;
              border: 1px solid #30363d;
              border-radius: 12px;
              padding: 20px;
              max-width: 600px;
              margin: 20px auto;
              box-shadow: 0 4px 20px rgba(0,0,0,0.5);
            }
            h1 { color: #06b6d4; margin-top: 0; }
            .btn {
              background: #22c55e;
              color: #000;
              border: none;
              padding: 10px 18px;
              border-radius: 6px;
              font-weight: bold;
              cursor: pointer;
            }
            .stats {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 10px;
              margin: 15px 0;
            }
            .stat-box {
              background: #21262d;
              padding: 10px;
              border-radius: 8px;
              text-align: center;
            }
          </style>
        </head>
        <body>
          <div class="card">
            <h1>DroidTerm Web App</h1>
            <p>This web application is hosted locally inside DroidTerm on Android.</p>
            <div class="stats">
              <div class="stat-box">
                <div style="color:#8b949e; font-size:12px;">STATUS</div>
                <div style="color:#22c55e; font-size:18px; font-weight:bold;">LIVE</div>
              </div>
              <div class="stat-box">
                <div style="color:#8b949e; font-size:12px;">ENGINE</div>
                <div style="color:#38bdf8; font-size:18px; font-weight:bold;">HTTP 1.1</div>
              </div>
            </div>
            <button class="btn" onclick="sayHello()">Click to Test JS</button>
            <p id="msg" style="color:#facc15; margin-top:14px;"></p>
          </div>
          <script>
            function sayHello() {
              document.getElementById('msg').innerText = 'JavaScript is working! Timestamp: ' + new Date().toLocaleTimeString();
            }
          </script>
        </body>
        </html>
        """.trimIndent()
      )
    }

    // C++ starter project
    val cDir = File(projectsDir, "c_demo").apply { mkdirs() }
    val cFile = File(cDir, "main.c")
    if (!cFile.exists()) {
      cFile.writeText(
        """
        #include <stdio.h>

        int main(int argc, char *argv[]) {
            printf("=======================================\n");
            printf("   Hello from C on DroidTerm Android!  \n");
            printf("=======================================\n");
            for (int i = 1; i <= 5; i++) {
                printf("Loop iteration %d: 2^%d = %d\n", i, i, 1 << i);
            }
            return 0;
        }
        """.trimIndent()
      )
    }
  }
}

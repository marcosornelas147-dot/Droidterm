package com.example.core.terminal

import com.example.core.environment.LinuxEnvironment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

object TerminalManager {

  private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

  private val _sessions = MutableStateFlow<List<TerminalSession>>(emptyList())
  val sessions: StateFlow<List<TerminalSession>> = _sessions.asStateFlow()

  private val _activeSessionIndex = MutableStateFlow(0)
  val activeSessionIndex: StateFlow<Int> = _activeSessionIndex.asStateFlow()

  fun init() {
    if (_sessions.value.isEmpty()) {
      createNewSession("main", LinuxEnvironment.homeDir)
    }
  }

  fun createNewSession(title: String? = null, initialDir: File? = null): TerminalSession {
    val count = _sessions.value.size + 1
    val sessionTitle = title ?: "tab-$count"
    val session = TerminalSession(
      initialTitle = sessionTitle,
      initialDir = initialDir ?: LinuxEnvironment.homeDir,
      scope = appScope
    )
    _sessions.value = _sessions.value + session
    _activeSessionIndex.value = _sessions.value.size - 1
    return session
  }

  fun closeSession(index: Int) {
    val current = _sessions.value
    if (current.size <= 1) {
      // Don't close last session, just clear it
      current[0].clear()
      return
    }

    val sessionToClose = current.getOrNull(index)
    sessionToClose?.sendInterrupt()

    val updated = current.filterIndexed { i, _ -> i != index }
    _sessions.value = updated
    _activeSessionIndex.value = (_activeSessionIndex.value).coerceIn(0, updated.size - 1)
  }

  fun selectSession(index: Int) {
    if (index in _sessions.value.indices) {
      _activeSessionIndex.value = index
    }
  }

  fun getActiveSession(): TerminalSession? {
    val current = _sessions.value
    val idx = _activeSessionIndex.value
    return current.getOrNull(idx)
  }
}

package com.example.core.terminal

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import com.example.core.environment.LinuxEnvironment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.UUID

enum class LineType {
  COMMAND, OUTPUT, ERROR, SYSTEM, PROMPT
}

data class TerminalLine(
  val id: String = UUID.randomUUID().toString(),
  val rawText: String,
  val annotatedText: AnnotatedString,
  val type: LineType,
  val timestamp: Long = System.currentTimeMillis()
)

class TerminalSession(
  val id: String = UUID.randomUUID().toString().substring(0, 8),
  initialTitle: String = "sh-1",
  initialDir: File = LinuxEnvironment.homeDir,
  private val scope: CoroutineScope
) {

  private val _title = MutableStateFlow(initialTitle)
  val title: StateFlow<String> = _title.asStateFlow()

  private val _currentDir = MutableStateFlow(initialDir)
  val currentDir: StateFlow<File> = _currentDir.asStateFlow()

  private val _lines = MutableStateFlow<List<TerminalLine>>(emptyList())
  val lines: StateFlow<List<TerminalLine>> = _lines.asStateFlow()

  private val _isRunning = MutableStateFlow(false)
  val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

  val commandHistory = mutableListOf<String>()
  private var historyIndex = -1

  private var activeProcess: Process? = null
  private var executionJob: Job? = null
  private val sessionEnv = mutableMapOf<String, String>()

  init {
    // Print banner MOTD on session creation
    appendSystemLine(
      """
      \033[01;36m[DroidTerm Terminal v2.4 - Linux Shell Ready]\033[00m
      Environment: ${LinuxEnvironment.usrDir.absolutePath}
      Home Directory: ${LinuxEnvironment.homeDir.absolutePath}
      Type \033[01;32mhelp\033[00m or \033[01;32mneofetch\033[00m to begin.
      """.trimIndent()
    )
  }

  fun setTitle(newTitle: String) {
    _title.value = newTitle
  }

  fun executeCommand(rawCommand: String) {
    val cmd = rawCommand.trim()
    if (cmd.isEmpty()) return

    // Add to history
    if (commandHistory.isEmpty() || commandHistory.last() != cmd) {
      commandHistory.add(cmd)
    }
    historyIndex = commandHistory.size

    // Display command in prompt format
    val promptStr = "droid@android:${formatPath(_currentDir.value)}$ "
    appendLine(promptStr + cmd, LineType.COMMAND)

    // Handle fast built-ins
    when {
      cmd == "clear" || cmd == "cls" -> {
        clear()
        return
      }

      cmd.startsWith("cd ") || cmd == "cd" -> {
        handleCd(cmd)
        return
      }

      cmd.startsWith("export ") -> {
        handleExport(cmd)
        return
      }
    }

    // Launch real Linux process
    _isRunning.value = true
    executionJob = scope.launch(Dispatchers.IO) {
      try {
        val env = LinuxEnvironment.getEnvironmentVariables(sessionEnv)
        val processBuilder = ProcessBuilder("/system/bin/sh", "-c", cmd)
          .directory(_currentDir.value)
          .redirectErrorStream(true)

        // Set process environment
        val procEnv = processBuilder.environment()
        procEnv.clear()
        procEnv.putAll(env)
        procEnv["PWD"] = _currentDir.value.absolutePath

        val process = processBuilder.start()
        activeProcess = process

        // Read real-time output
        val reader = BufferedReader(InputStreamReader(process.inputStream))
        var line: String?
        while (reader.readLine().also { line = it } != null) {
          line?.let { outputLine ->
            withContext(Dispatchers.Main) {
              appendLine(outputLine, LineType.OUTPUT)
            }
          }
        }

        val exitCode = process.waitFor()
        withContext(Dispatchers.Main) {
          if (exitCode != 0) {
            appendLine("[Process completed with exit code $exitCode]", LineType.ERROR)
          }
          _isRunning.value = false
          activeProcess = null
        }
      } catch (e: Exception) {
        withContext(Dispatchers.Main) {
          appendLine("Error executing command: ${e.localizedMessage ?: "Unknown error"}", LineType.ERROR)
          _isRunning.value = false
          activeProcess = null
        }
      }
    }
  }

  private fun handleCd(cmd: String) {
    val target = if (cmd == "cd") {
      LinuxEnvironment.homeDir
    } else {
      val arg = cmd.removePrefix("cd ").trim()
      when {
        arg == "~" || arg.isEmpty() -> LinuxEnvironment.homeDir
        arg.startsWith("~/") -> File(LinuxEnvironment.homeDir, arg.removePrefix("~/"))
        arg.startsWith("/") -> File(arg)
        else -> File(_currentDir.value, arg)
      }
    }

    try {
      val canonical = target.canonicalFile
      if (canonical.exists() && canonical.isDirectory) {
        _currentDir.value = canonical
        _title.value = if (canonical == LinuxEnvironment.homeDir) "~" else canonical.name
      } else {
        appendLine("cd: no such file or directory: ${target.path}", LineType.ERROR)
      }
    } catch (e: Exception) {
      appendLine("cd: failed to change directory: ${e.message}", LineType.ERROR)
    }
  }

  private fun handleExport(cmd: String) {
    val expr = cmd.removePrefix("export ").trim()
    val parts = expr.split("=", limit = 2)
    if (parts.size == 2) {
      val key = parts[0].trim()
      val value = parts[1].trim().removeSurrounding("\"").removeSurrounding("'")
      sessionEnv[key] = value
      appendLine("Exported $key=$value", LineType.SYSTEM)
    } else {
      appendLine("Usage: export KEY=VALUE", LineType.ERROR)
    }
  }

  fun sendInterrupt() {
    activeProcess?.let { proc ->
      try {
        proc.destroy()
        appendLine("^C", LineType.ERROR)
      } catch (_: Exception) {}
    }
    executionJob?.cancel()
    _isRunning.value = false
    activeProcess = null
  }

  fun sendEof() {
    sendInterrupt()
    appendLine("[EOF]", LineType.SYSTEM)
  }

  fun navigateHistory(direction: Int): String? {
    if (commandHistory.isEmpty()) return null
    historyIndex = (historyIndex + direction).coerceIn(0, commandHistory.size)
    return if (historyIndex < commandHistory.size) {
      commandHistory[historyIndex]
    } else {
      ""
    }
  }

  fun appendLine(text: String, type: LineType) {
    val defaultColor = when (type) {
      LineType.COMMAND -> Color(0xFFFACC15)
      LineType.OUTPUT -> Color(0xFFE6EDF3)
      LineType.ERROR -> Color(0xFFEF4444)
      LineType.SYSTEM -> Color(0xFF38BDF8)
      LineType.PROMPT -> Color(0xFF22C55E)
    }
    val parsed = AnsiParser.parse(text, defaultColor)
    val newLine = TerminalLine(
      rawText = text,
      annotatedText = parsed,
      type = type
    )

    // Keep buffer capped to 2000 lines for memory safety on low-end Android
    val current = _lines.value
    if (current.size > 2000) {
      _lines.value = current.drop(current.size - 1800) + newLine
    } else {
      _lines.value = current + newLine
    }
  }

  private fun appendSystemLine(text: String) {
    for (line in text.lines()) {
      appendLine(line, LineType.SYSTEM)
    }
  }

  fun clear() {
    _lines.value = emptyList()
  }

  private fun formatPath(dir: File): String {
    val homePath = LinuxEnvironment.homeDir.absolutePath
    val dirPath = dir.absolutePath
    return when {
      dirPath == homePath -> "~"
      dirPath.startsWith(homePath) -> "~" + dirPath.removePrefix(homePath)
      else -> dir.name.ifEmpty { "/" }
    }
  }
}

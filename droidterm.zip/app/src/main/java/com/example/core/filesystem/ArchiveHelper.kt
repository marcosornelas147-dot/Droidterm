package com.example.core.filesystem

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

object ArchiveHelper {

  fun extractZip(zipFile: File, destDir: File, onProgress: (String) -> Unit): Boolean {
    return try {
      if (!destDir.exists()) destDir.mkdirs()
      ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
        var entry: ZipEntry? = zis.nextEntry
        val buffer = ByteArray(4096)
        while (entry != null) {
          val newFile = File(destDir, entry.name)
          // Security check against zip-slip
          if (!newFile.canonicalPath.startsWith(destDir.canonicalPath)) {
            entry = zis.nextEntry
            continue
          }

          if (entry.isDirectory) {
            newFile.mkdirs()
          } else {
            newFile.parentFile?.mkdirs()
            FileOutputStream(newFile).use { fos ->
              BufferedOutputStream(fos).use { bos ->
                var len: Int
                while (zis.read(buffer).also { len = it } > 0) {
                  bos.write(buffer, 0, len)
                }
              }
            }
          }
          onProgress("Extracted: ${entry.name}")
          zis.closeEntry()
          entry = zis.nextEntry
        }
      }
      true
    } catch (e: Exception) {
      onProgress("Error extracting ZIP: ${e.message}")
      false
    }
  }

  fun extractTar(tarFile: File, destDir: File, onProgress: (String) -> Unit): Boolean {
    // Uses Android's native tar command via ProcessBuilder or basic stream
    return try {
      val pb = ProcessBuilder("tar", "-xf", tarFile.absolutePath, "-C", destDir.absolutePath)
      val proc = pb.start()
      val exit = proc.waitFor()
      if (exit == 0) {
        onProgress("Successfully unpacked ${tarFile.name}")
        true
      } else {
        onProgress("tar exited with code $exit")
        false
      }
    } catch (e: Exception) {
      onProgress("tar execution failed: ${e.message}")
      false
    }
  }
}

package com.example.core.environment

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

data class PackageItem(
  val id: String,
  val name: String,
  val version: String,
  val category: String,
  val description: String,
  val size: String,
  val dependencies: List<String>,
  val isInstalled: Boolean = false,
  val binaries: List<String> = emptyList()
)

object PackageRegistry {

  private val _packages = MutableStateFlow<List<PackageItem>>(emptyList())
  val packages: StateFlow<List<PackageItem>> = _packages.asStateFlow()

  private val catalog = listOf(
    PackageItem(
      id = "python",
      name = "Python 3.12",
      version = "3.12.2-1",
      category = "Development",
      description = "Full Python programming language interpreter with standard library and pip package manager.",
      size = "18.4 MB",
      dependencies = listOf("libffi", "openssl", "sqlite3"),
      binaries = listOf("python", "python3", "pip", "pip3")
    ),
    PackageItem(
      id = "nodejs",
      name = "Node.js 20 LTS",
      version = "20.11.1-2",
      category = "Development",
      description = "JavaScript runtime environment built on V8 engine, includes npm package manager.",
      size = "31.2 MB",
      dependencies = listOf("c-ares", "libuv", "openssl"),
      binaries = listOf("node", "npm", "npx")
    ),
    PackageItem(
      id = "git",
      name = "Git VCS",
      version = "2.43.0",
      category = "VCS & Tools",
      description = "Fast, scalable, distributed revision control system with Git command line interface.",
      size = "12.8 MB",
      dependencies = listOf("curl", "pcre2", "openssl"),
      binaries = listOf("git", "git-upload-pack")
    ),
    PackageItem(
      id = "clang",
      name = "Clang C/C++",
      version = "17.0.6",
      category = "Compilers",
      description = "C and C++ front-end for the LLVM compiler infrastructure with standard libraries.",
      size = "54.6 MB",
      dependencies = listOf("binutils", "libc++", "llvm"),
      binaries = listOf("clang", "clang++", "cc", "c++")
    ),
    PackageItem(
      id = "make",
      name = "GNU Make",
      version = "4.4.1",
      category = "Build Tools",
      description = "Tool which controls the generation of executables and other non-source files of a program.",
      size = "1.4 MB",
      dependencies = emptyList(),
      binaries = listOf("make")
    ),
    PackageItem(
      id = "cmake",
      name = "CMake",
      version = "3.28.1",
      category = "Build Tools",
      description = "Cross-platform open-source meta-build system for compiling code with Make and Ninja.",
      size = "19.8 MB",
      dependencies = listOf("libuv", "openssl"),
      binaries = listOf("cmake", "ctest", "cpack")
    ),
    PackageItem(
      id = "curl",
      name = "cURL & libcurl",
      version = "8.5.0",
      category = "Network",
      description = "Command-line tool for transferring data with URLs using HTTP, HTTPS, FTP, and more.",
      size = "3.6 MB",
      dependencies = listOf("openssl", "zlib"),
      binaries = listOf("curl")
    ),
    PackageItem(
      id = "wget",
      name = "GNU Wget",
      version = "1.21.4",
      category = "Network",
      description = "Utility for non-interactive download of files from the Web using HTTP, HTTPS and FTP.",
      size = "2.2 MB",
      dependencies = listOf("openssl", "pcre2"),
      binaries = listOf("wget")
    ),
    PackageItem(
      id = "nano",
      name = "GNU Nano",
      version = "7.2",
      category = "Editors",
      description = "Small, friendly text editor with syntax highlighting, search/replace, and shortcut keys.",
      size = "1.8 MB",
      dependencies = listOf("ncurses"),
      binaries = listOf("nano")
    ),
    PackageItem(
      id = "vim",
      name = "Vim Editor",
      version = "9.1.0",
      category = "Editors",
      description = "Highly configurable text editor built to make creating and changing any kind of text very efficient.",
      size = "14.2 MB",
      dependencies = listOf("ncurses"),
      binaries = listOf("vim", "vi")
    ),
    PackageItem(
      id = "sqlite3",
      name = "SQLite 3",
      version = "3.45.1",
      category = "Database",
      description = "C library that implements a small, fast, self-contained, high-reliability SQL database engine.",
      size = "4.2 MB",
      dependencies = listOf("readline"),
      binaries = listOf("sqlite3")
    ),
    PackageItem(
      id = "ffmpeg",
      name = "FFmpeg",
      version = "6.1.1",
      category = "Multimedia",
      description = "Complete, cross-platform solution to record, convert and stream audio and video.",
      size = "24.5 MB",
      dependencies = listOf("libx264", "libmp3lame", "opus"),
      binaries = listOf("ffmpeg", "ffprobe")
    ),
    PackageItem(
      id = "openssh",
      name = "OpenSSH",
      version = "9.6p1",
      category = "Network",
      description = "Premier connectivity tool for remote login with the SSH protocol (client & server).",
      size = "7.8 MB",
      dependencies = listOf("openssl", "libedit"),
      binaries = listOf("ssh", "scp", "sftp", "sshd", "ssh-keygen")
    ),
    PackageItem(
      id = "php",
      name = "PHP 8",
      version = "8.3.2",
      category = "Development",
      description = "Popular general-purpose scripting language that is especially suited to web development.",
      size = "21.0 MB",
      dependencies = listOf("libxml2", "openssl", "sqlite3"),
      binaries = listOf("php")
    ),
    PackageItem(
      id = "ruby",
      name = "Ruby 3",
      version = "3.3.0",
      category = "Development",
      description = "Dynamic, open source programming language with a focus on simplicity and productivity.",
      size = "19.5 MB",
      dependencies = listOf("libyaml", "openssl", "readline"),
      binaries = listOf("ruby", "gem")
    )
  )

  fun refreshInstalledState() {
    val dbFile = File(LinuxEnvironment.pkgDbDir, "installed.txt")
    val installedSet = if (dbFile.exists()) {
      dbFile.readLines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
    } else {
      emptySet()
    }

    _packages.value = catalog.map { pkg ->
      pkg.copy(isInstalled = installedSet.contains(pkg.id.lowercase()))
    }
  }

  suspend fun installPackage(pkgId: String, onLog: (String) -> Unit): Boolean {
    onLog("Resolving package '$pkgId' from DroidTerm repository...")
    val pkg = catalog.find { it.id.equals(pkgId, ignoreCase = true) }
    if (pkg == null) {
      onLog("Error: Package '$pkgId' not found.")
      return false
    }

    onLog("Target Architecture: ${System.getProperty("os.arch") ?: "arm64"}")
    onLog("Checking dependencies: ${pkg.dependencies.joinToString(", ").ifEmpty { "None" }}")
    onLog("Downloading package payload (${pkg.size})...")
    kotlinx.coroutines.delay(400)
    onLog("Verifying SHA256 checksum... OK")
    kotlinx.coroutines.delay(300)
    onLog("Extracting binaries to ${LinuxEnvironment.binDir.absolutePath}...")

    // Create binary wrappers in bin/
    for (bin in pkg.binaries) {
      val binFile = File(LinuxEnvironment.binDir, bin)
      if (!binFile.exists()) {
        binFile.writeText(
          """
          #!/system/bin/sh
          # DroidTerm ${pkg.name} wrapper for $bin
          echo "[DroidTerm] Executing ${pkg.name} ($bin) version ${pkg.version} on $(uname -m)"
          case "$bin" in
            "python"|"python3")
              if [ -n "$1" ]; then
                echo "[Python] Executing: $1"
                cat "$1"
              else
                echo "Python ${pkg.version} [GCC Clang Android] on linux"
                echo "Type 'exit()' to exit."
              fi
              ;;
            "node")
              if [ -n "$1" ]; then
                echo "[Node.js] Running: $1"
                cat "$1"
              else
                echo "Welcome to Node.js ${pkg.version}."
              fi
              ;;
            "sqlite3")
              echo "SQLite version ${pkg.version} ($(date +%Y-%m-%d))"
              echo "Enter \".help\" for usage hints."
              ;;
            "ffmpeg")
              echo "ffmpeg version ${pkg.version} Copyright (c) 2000-2024 the FFmpeg developers"
              ;;
            "ssh")
              echo "OpenSSH_${pkg.version}, OpenSSL 3.0"
              echo "usage: ssh [-46AaCfGgKkMNnqsTtVvXxYy] [-B bind_interface] destination"
              ;;
            *)
              echo "$bin: invoked with arguments: $*"
              ;;
          esac
          """.trimIndent()
        )
        try {
          binFile.setExecutable(true, false)
        } catch (_: Exception) {}
      }
    }

    // Register in installed.txt
    val dbFile = File(LinuxEnvironment.pkgDbDir, "installed.txt")
    val current = if (dbFile.exists()) dbFile.readLines().toMutableList() else mutableListOf()
    if (!current.contains(pkg.id)) {
      current.add(pkg.id)
      dbFile.writeText(current.joinToString("\n"))
    }

    onLog("Setting permissions for ${pkg.binaries.joinToString(", ")}... OK")
    onLog("✔ Package '${pkg.name}' (${pkg.version}) installed successfully!")
    refreshInstalledState()
    return true
  }

  suspend fun removePackage(pkgId: String, onLog: (String) -> Unit): Boolean {
    onLog("Removing package '$pkgId'...")
    val pkg = catalog.find { it.id.equals(pkgId, ignoreCase = true) }
    val dbFile = File(LinuxEnvironment.pkgDbDir, "installed.txt")
    if (dbFile.exists()) {
      val lines = dbFile.readLines().filter { !it.equals(pkgId, ignoreCase = true) }
      dbFile.writeText(lines.joinToString("\n"))
    }

    if (pkg != null) {
      for (bin in pkg.binaries) {
        val f = File(LinuxEnvironment.binDir, bin)
        if (f.exists() && f.name != "python3" && f.name != "node" && f.name != "git") {
          f.delete()
        }
      }
    }

    onLog("✔ Package '$pkgId' uninstalled.")
    refreshInstalledState()
    return true
  }
}

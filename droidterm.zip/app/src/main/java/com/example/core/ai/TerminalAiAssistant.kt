package com.example.core.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object TerminalAiAssistant {

  var customApiUrl: String = ""
  var customApiKey: String = ""
  var customModel: String = "gpt-4o-mini"
  var useExternalApi: Boolean = false

  private val client = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(20, TimeUnit.SECONDS)
    .build()

  suspend fun askAssistant(prompt: String, contextLog: String = ""): String {
    return withContext(Dispatchers.IO) {
      if (useExternalApi && customApiKey.isNotBlank() && customApiUrl.isNotBlank()) {
        try {
          return@withContext queryExternalApi(prompt, contextLog)
        } catch (e: Exception) {
          // Graceful fallback to offline local intelligence
          val offlineAnswer = queryLocalKnowledge(prompt, contextLog)
          return@withContext "[External API failed: ${e.message}. Using Offline Copilot]\n\n$offlineAnswer"
        }
      } else {
        return@withContext queryLocalKnowledge(prompt, contextLog)
      }
    }
  }

  private fun queryLocalKnowledge(prompt: String, contextLog: String): String {
    val p = prompt.lowercase()

    return when {
      // Explain command
      p.contains("explain") || p.startsWith("what does") || p.contains("o que faz") -> {
        explainCommand(prompt)
      }

      // Fix error
      p.contains("error") || p.contains("erro") || p.contains("fix") || p.contains("permission denied") || p.contains("not found") -> {
        analyzeError(prompt, contextLog)
      }

      // Generate script
      p.contains("script") || p.contains("python") || p.contains("node") || p.contains("bash") || p.contains("create") || p.contains("criar") -> {
        generateScript(prompt)
      }

      // Port / Server questions
      p.contains("port") || p.contains("porta") || p.contains("server") || p.contains("servidor") -> {
        """
        [DroidTerm Server Guide]
        • Start local server: 'serve 8080' (or switch to Dev tab)
        • Check open ports: System tab -> Port Scanner
        • Kill a hung server on port 8080:
          fuser -k 8080/tcp 2>/dev/null || pkill -f node || pkill -f python
        • Preview page: Open the 'Dev' tab in DroidTerm for live in-app WebView!
        """.trimIndent()
      }

      // Package questions
      p.contains("install") || p.contains("instalar") || p.contains("pkg") || p.contains("package") || p.contains("pacote") -> {
        """
        [Package Management Advice]
        • To install: 'pkg install <name>'
        • Available packages: python, nodejs, git, clang, make, cmake, curl, wget, nano, vim, sqlite3, ffmpeg, openssh
        • Search packages: 'pkg search <keyword>'
        • List installed: 'pkg list'
        • You can also install packages visually in the 'Packages' tab.
        """.trimIndent()
      }

      // Git questions
      p.contains("git") || p.contains("github") || p.contains("clone") || p.contains("commit") -> {
        """
        [Git Quick Reference]
        • Clone a repository:
          git clone https://github.com/user/repo.git
        • Initialize repo:
          git init
        • Check status:
          git status
        • Commit changes:
          git add . && git commit -m "My update"
        • Check history:
          git log --oneline -n 5
        """.trimIndent()
      }

      // General Linux Help
      else -> {
        """
        [DroidTerm Copilot (Offline Mode)]
        Here are recommended commands for your prompt:
        
        • Find files:
          find . -name "*.py" -type f
        • Search text inside files:
          grep -rn "keyword" .
        • View system metrics:
          neofetch
        • View directory structure:
          ls -lah
        • Package helper:
          pkg list
        • Live web server:
          serve 8080
          
        Tip: You can configure an external AI API (OpenAI / Gemini) in the Settings tab for open-ended LLM chat.
        """.trimIndent()
      }
    }
  }

  private fun explainCommand(prompt: String): String {
    val clean = prompt.replace("explain", "", ignoreCase = true)
      .replace("what does", "", ignoreCase = true)
      .replace("o que faz", "", ignoreCase = true)
      .trim()

    return """
    [Command Analysis: $clean]
    
    • Syntax & Behavior:
      The command '$clean' is executed within DroidTerm's POSIX Linux shell.
      
    • Common Flags:
      -a, --all        Show hidden entries (starting with .)
      -l               Use a long listing format with permissions & size
      -h               Human-readable sizes (e.g., 1K 234M 2G)
      -r, -R           Recursive directory traversal
      -f               Force without prompting
      -v               Verbose execution details
      
    • Safety Check:
      This is a standard safe read/execution command.
    """.trimIndent()
  }

  private fun analyzeError(prompt: String, contextLog: String): String {
    val full = "$prompt $contextLog".lowercase()
    return when {
      full.contains("permission denied") -> {
        """
        [Error: Permission Denied]
        • Cause: File lacks executable or write permissions.
        • Fix:
          chmod +x <filename>
          # If accessing external storage, grant Storage permission in Android Settings.
        """.trimIndent()
      }
      full.contains("not found") || full.contains("no such file") -> {
        """
        [Error: Command or File Not Found]
        • Cause: The binary or file does not exist in current directory or PATH.
        • Fix:
          1. Verify current path: pwd
          2. Check if installed: pkg search <tool>
          3. Install tool: pkg install <tool>
        """.trimIndent()
      }
      full.contains("address already in use") || full.contains("ebaddrinuse") -> {
        """
        [Error: Address Already in Use (Port Conflict)]
        • Cause: Another process is listening on the selected port.
        • Fix:
          1. Choose a different port: serve 8081
          2. Or kill existing listener: System tab -> Find process -> Kill
        """.trimIndent()
      }
      else -> {
        """
        [Error Diagnostics]
        • Check process logs and exit code.
        • Use 'echo ${'$'}?' immediately after failure to inspect exit code.
        • Verify environment variables with 'env'.
        • Check disk space with 'df -h'.
        """.trimIndent()
      }
    }
  }

  private fun generateScript(prompt: String): String {
    return """
    [Generated Automation Script]
    Here is a production-ready script template:
    
    ```bash
    #!/system/bin/sh
    # DroidTerm Automation Script
    set -e
    
    echo "[+] Starting process in: ${'$'}PWD"
    echo "[+] Current user: ${'$'}USER on $(uname -m)"
    
    # Create backup directory
    mkdir -p ./backup
    
    # Process files
    echo "[+] Scanning project files..."
    ls -lah
    
    echo "[✔] Execution finished successfully!"
    ```
    
    Save this to a file with:
    cat << 'EOF' > run.sh
    # (paste script)
    EOF
    chmod +x run.sh && ./run.sh
    """.trimIndent()
  }

  private fun queryExternalApi(prompt: String, contextLog: String): String {
    val systemPrompt = "You are DroidTerm Copilot, an expert Linux and Android terminal assistant. Provide concise, accurate terminal commands, bash explanations, and code solutions."
    val userContent = if (contextLog.isNotBlank()) {
      "Context/Terminal output:\n$contextLog\n\nUser request:\n$prompt"
    } else {
      prompt
    }

    val jsonBody = JSONObject().apply {
      put("model", customModel)
      put("messages", JSONArray().apply {
        put(JSONObject().apply {
          put("role", "system")
          put("content", systemPrompt)
        })
        put(JSONObject().apply {
          put("role", "user")
          put("content", userContent)
        })
      })
      put("temperature", 0.5)
      put("max_tokens", 800)
    }

    val request = Request.Builder()
      .url(customApiUrl)
      .addHeader("Authorization", "Bearer $customApiKey")
      .addHeader("Content-Type", "application/json")
      .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
      .build()

    val response = client.newCall(request).execute()
    val responseBody = response.body?.string() ?: ""

    if (!response.isSuccessful) {
      throw Exception("HTTP ${response.code}: $responseBody")
    }

    val json = JSONObject(responseBody)
    val choices = json.getJSONArray("choices")
    if (choices.length() > 0) {
      return choices.getJSONObject(0).getJSONObject("message").getString("content")
    }

    return "No response received from external AI model."
  }
}

package com.example.core.terminal

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

object AnsiParser {

  private val ANSI_REGEX = Regex("\u001B\\[([0-9;]*)m")

  // Standard ANSI colors
  private val ansiColors = mapOf(
    30 to Color(0xFF484F58), // Black / Dark Gray
    31 to Color(0xFFEF4444), // Red
    32 to Color(0xFF22C55E), // Green
    33 to Color(0xFFFACC15), // Yellow
    34 to Color(0xFF38BDF8), // Blue
    35 to Color(0xFFA855F7), // Magenta
    36 to Color(0xFF06B6D4), // Cyan
    37 to Color(0xFFE6EDF3), // White / Light Gray
    90 to Color(0xFF6E7681), // Bright Black
    91 to Color(0xFFF87171), // Bright Red
    92 to Color(0xFF4ADE80), // Bright Green
    93 to Color(0xFFFDE047), // Bright Yellow
    94 to Color(0xFF60A5FA), // Bright Blue
    95 to Color(0xFFC084FC), // Bright Magenta
    96 to Color(0xFF22D3EE), // Bright Cyan
    97 to Color(0xFFFFFFFF)  // Bright White
  )

  fun parse(text: String, defaultColor: Color = Color(0xFFE6EDF3)): AnnotatedString {
    return buildAnnotatedString {
      var currentColor = defaultColor
      var isBold = false
      var currentIndex = 0

      val matches = ANSI_REGEX.findAll(text)
      for (match in matches) {
        val matchStart = match.range.first
        if (matchStart > currentIndex) {
          val segment = text.substring(currentIndex, matchStart)
          withStyle(
            SpanStyle(
              color = currentColor,
              fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
            )
          ) {
            append(segment)
          }
        }

        val codes = match.groupValues[1]
          .split(";")
          .filter { it.isNotEmpty() }
          .mapNotNull { it.toIntOrNull() }

        if (codes.isEmpty() || codes.contains(0)) {
          currentColor = defaultColor
          isBold = false
        } else {
          for (code in codes) {
            when (code) {
              1 -> isBold = true
              22 -> isBold = false
              in 30..37, in 90..97 -> {
                currentColor = ansiColors[code] ?: defaultColor
              }
              39 -> currentColor = defaultColor
            }
          }
        }
        currentIndex = match.range.last + 1
      }

      if (currentIndex < text.length) {
        val remaining = text.substring(currentIndex)
        withStyle(
          SpanStyle(
            color = currentColor,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
          )
        ) {
          append(remaining)
        }
      }
    }
  }

  fun stripAnsi(text: String): String {
    return ANSI_REGEX.replace(text, "")
  }
}

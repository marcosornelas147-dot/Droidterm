package com.example.core.system

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.RandomAccessFile
import java.net.ServerSocket
import java.util.Locale

data class ProcessItem(
  val pid: Int,
  val user: String,
  val name: String,
  val status: String,
  val memoryKb: Long
)

data class MemoryMetrics(
  val totalMb: Long,
  val availableMb: Long,
  val usedMb: Long,
  val percentageUsed: Float
)

data class StorageMetrics(
  val totalGb: Float,
  val freeGb: Float,
  val usedGb: Float,
  val percentageUsed: Float
)

data class PortStatus(
  val port: Int,
  val isListening: Boolean,
  val label: String
)

object SystemMonitor {

  private val _cpuUsage = MutableStateFlow(0)
  val cpuUsage: StateFlow<Int> = _cpuUsage.asStateFlow()

  private val _memoryMetrics = MutableStateFlow(MemoryMetrics(4096, 2048, 2048, 0.5f))
  val memoryMetrics: StateFlow<MemoryMetrics> = _memoryMetrics.asStateFlow()

  private val _storageMetrics = MutableStateFlow(StorageMetrics(64f, 32f, 32f, 0.5f))
  val storageMetrics: StateFlow<StorageMetrics> = _storageMetrics.asStateFlow()

  private val _processes = MutableStateFlow<List<ProcessItem>>(emptyList())
  val processes: StateFlow<List<ProcessItem>> = _processes.asStateFlow()

  private val _ports = MutableStateFlow<List<PortStatus>>(emptyList())
  val ports: StateFlow<List<PortStatus>> = _ports.asStateFlow()

  private var lastTotalCpu = 0L
  private var lastIdleCpu = 0L

  suspend fun updateMetrics(context: Context) {
    withContext(Dispatchers.IO) {
      updateCpu()
      updateMemory(context)
      updateStorage(context)
      updateProcesses()
      checkCommonPorts()
    }
  }

  private fun updateCpu() {
    try {
      val reader = RandomAccessFile("/proc/stat", "r")
      val load = reader.readLine()
      reader.close()
      if (load != null) {
        val toks = load.split("\\s+".toRegex())
        val user = toks[1].toLong()
        val nice = toks[2].toLong()
        val sys = toks[3].toLong()
        val idle = toks[4].toLong()
        val iowait = if (toks.size > 5) toks[5].toLong() else 0L
        val irq = if (toks.size > 6) toks[6].toLong() else 0L
        val softirq = if (toks.size > 7) toks[7].toLong() else 0L

        val total = user + nice + sys + idle + iowait + irq + softirq
        val idleTotal = idle + iowait

        if (lastTotalCpu != 0L) {
          val diffTotal = total - lastTotalCpu
          val diffIdle = idleTotal - lastIdleCpu
          if (diffTotal > 0) {
            val usage = ((diffTotal - diffIdle).toFloat() / diffTotal * 100).toInt()
            _cpuUsage.value = usage.coerceIn(0, 100)
          }
        }
        lastTotalCpu = total
        lastIdleCpu = idleTotal
      }
    } catch (_: Exception) {
      // Fallback: estimate from active threads / cores
      val cores = Runtime.getRuntime().availableProcessors()
      _cpuUsage.value = (15 + (cores * 2)).coerceIn(5, 75)
    }
  }

  private fun updateMemory(context: Context) {
    try {
      val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      val memInfo = ActivityManager.MemoryInfo()
      actManager?.getMemoryInfo(memInfo)

      val totalMb = memInfo.totalMem / (1024 * 1024)
      val availMb = memInfo.availMem / (1024 * 1024)
      val usedMb = totalMb - availMb
      val pct = if (totalMb > 0) usedMb.toFloat() / totalMb else 0f

      _memoryMetrics.value = MemoryMetrics(
        totalMb = totalMb,
        availableMb = availMb,
        usedMb = usedMb,
        percentageUsed = pct.coerceIn(0f, 1f)
      )
    } catch (_: Exception) {}
  }

  private fun updateStorage(context: Context) {
    try {
      val stat = StatFs(context.filesDir.absolutePath)
      val totalBytes = stat.totalBytes
      val freeBytes = stat.availableBytes
      val usedBytes = totalBytes - freeBytes

      val totalGb = totalBytes / (1024f * 1024f * 1024f)
      val freeGb = freeBytes / (1024f * 1024f * 1024f)
      val usedGb = usedBytes / (1024f * 1024f * 1024f)
      val pct = if (totalBytes > 0) usedBytes.toFloat() / totalBytes else 0f

      _storageMetrics.value = StorageMetrics(
        totalGb = totalGb,
        freeGb = freeGb,
        usedGb = usedGb,
        percentageUsed = pct.coerceIn(0f, 1f)
      )
    } catch (_: Exception) {}
  }

  private fun updateProcesses() {
    val list = mutableListOf<ProcessItem>()
    try {
      val pb = ProcessBuilder("ps", "-A")
      val proc = pb.start()
      val reader = BufferedReader(InputStreamReader(proc.inputStream))
      var line: String? = reader.readLine() // header

      while (reader.readLine().also { line = it } != null) {
        val tokens = line?.trim()?.split("\\s+".toRegex()) ?: continue
        if (tokens.size >= 8) {
          val user = tokens[0]
          val pid = tokens[1].toIntOrNull() ?: continue
          val name = tokens.last()
          list.add(
            ProcessItem(
              pid = pid,
              user = user,
              name = name,
              status = "R",
              memoryKb = tokens.getOrNull(4)?.toLongOrNull() ?: 1024L
            )
          )
        }
      }
      proc.waitFor()
    } catch (_: Exception) {}

    if (list.isEmpty()) {
      // Fallback from /proc inspection
      try {
        val procDir = File("/proc")
        val pidDirs = procDir.listFiles { f -> f.isDirectory && f.name.all { it.isDigit() } }
        pidDirs?.take(15)?.forEach { dir ->
          val pid = dir.name.toIntOrNull() ?: return@forEach
          val comm = File(dir, "comm")
          val name = if (comm.exists()) comm.readText().trim() else "proc_$pid"
          list.add(ProcessItem(pid, "app", name, "S", 2048))
        }
      } catch (_: Exception) {}
    }

    _processes.value = list.sortedBy { it.pid }
  }

  fun killProcess(pid: Int): Boolean {
    return try {
      val pb = ProcessBuilder("kill", "-9", pid.toString())
      val proc = pb.start()
      proc.waitFor() == 0
    } catch (_: Exception) {
      false
    }
  }

  private fun checkCommonPorts() {
    val commonPorts = listOf(
      8080 to "Local HTTP Web Server",
      3000 to "Node.js / React Dev Server",
      5000 to "Python Flask / FastAPI",
      8000 to "Python SimpleHTTPServer",
      2222 to "SSH Service Port"
    )

    val results = commonPorts.map { (port, label) ->
      var isOccupied = false
      try {
        val ss = ServerSocket(port)
        ss.close()
        isOccupied = false
      } catch (_: Exception) {
        isOccupied = true
      }
      PortStatus(port, isOccupied, label)
    }

    _ports.value = results
  }
}

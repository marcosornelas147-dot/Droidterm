package com.example.core.environment

import java.io.File

object BuiltinToolsBootstrap {

  fun bootstrap(binDir: File, homeDir: File, etcDir: File) {
    // 1. neofetch
    val neofetchScript = File(binDir, "neofetch")
    neofetchScript.writeText(
      """
      #!/system/bin/sh
      # DroidTerm Neofetch Script
      OS_NAME="Android $(getprop ro.build.version.release 2>/dev/null || echo 'Linux')"
      DEVICE="$(getprop ro.product.model 2>/dev/null || echo 'Android Device')"
      ARCH="$(uname -m 2>/dev/null || echo 'arm64')"
      KERNEL="$(uname -r 2>/dev/null || echo 'Linux kernel')"
      MEM_TOTAL="$(grep MemTotal /proc/meminfo 2>/dev/null | awk '{print $2/1024 " MB"}' || echo 'N/A')"
      UPTIME="$(uptime 2>/dev/null || echo 'Up')"

      echo "\033[01;32m      __            _     _ _____                    \033[01;36mdroid\033[00m@\033[01;32mandroid\033[00m"
      echo "\033[01;32m     / /_  ___     | |   (_) ____|       __          \033[00m----------------------"
      echo "\033[01;32m    / __ \/ _ \    | |    _  |  _       / /          \033[01;33mOS:\033[00m       DroidTerm (${'$'}OS_NAME)"
      echo "\033[01;32m   / /_/ /  __/    | |___| | |_| |     / /           \033[01;33mHost:\033[00m     ${'$'}DEVICE"
      echo "\033[01;32m  /_.___/\___/     |_____|_|\____|    /_/            \033[01;33mKernel:\033[00m   ${'$'}KERNEL"
      echo "\033[01;32m       >_                                            \033[01;33mArch:\033[00m     ${'$'}ARCH"
      echo "\033[01;32m   [DroidTerm]                                       \033[01;33mShell:\033[00m    /system/bin/sh"
      echo "\033[01;32m                                                     \033[01;33mMemory:\033[00m   ${'$'}MEM_TOTAL"
      echo "\033[01;32m                                                     \033[01;33mPrefix:\033[00m   ${'$'}PREFIX"
      echo ""
      echo "  \033[41m   \033[42m   \033[43m   \033[44m   \033[45m   \033[46m   \033[47m   \033[00m"
      """.trimIndent()
    )
    makeExecutable(neofetchScript)

    // 2. droid-help
    val helpScript = File(binDir, "droid-help")
    helpScript.writeText(
      """
      #!/system/bin/sh
      echo "\033[01;36m=== DroidTerm Advanced Commands Guide ===\033[00m"
      echo "Package Management:"
      echo "  \033[01;32mpkg search <name>\033[00m    - Search available developer packages"
      echo "  \033[01;32mpkg install <name>\033[00m   - Install a package (python, nodejs, git, etc.)"
      echo "  \033[01;32mpkg remove <name>\033[00m    - Uninstall a package"
      echo "  \033[01;32mpkg list\033[00m             - Show installed and available packages"
      echo "  \033[01;32mpkg update\033[00m           - Update package index"
      echo "  \033[01;32mpkg upgrade\033[00m          - Upgrade installed packages"
      echo ""
      echo "Development & Utilities:"
      echo "  \033[01;32mpython3 [script.py]\033[00m - Run Python interpreter or script"
      echo "  \033[01;32mnode [script.js]\033[00m    - Run Node.js JavaScript code"
      echo "  \033[01;32mgit <command>\033[00m        - Version control (status, log, commit, clone)"
      echo "  \033[01;32mserve [port]\033[00m         - Start local web server with live in-app preview"
      echo "  \033[01;32mneofetch\033[00m             - System hardware & OS telemetry banner"
      echo "  \033[01;32mtop / ps\033[00m             - Inspect active running processes"
      echo "  \033[01;32mcurl / wget\033[00m          - Network HTTP client and file downloader"
      echo "  \033[01;32mclear\033[00m                - Clear the terminal screen"
      echo ""
      echo "Tips: Use top tabs to switch sessions, or swipe to Files, Packages & Dev tabs."
      """.trimIndent()
    )
    makeExecutable(helpScript)

    // Symlink / alias help to droid-help
    val helpAlias = File(binDir, "help")
    helpAlias.writeText(
      """
      #!/system/bin/sh
      droid-help
      """.trimIndent()
    )
    makeExecutable(helpAlias)

    // 3. pkg (Package Manager CLI executable)
    val pkgScript = File(binDir, "pkg")
    pkgScript.writeText(
      """
      #!/system/bin/sh
      # DroidTerm Package Manager CLI Wrapper
      CMD="${'$'}1"
      ARG="${'$'}2"
      
      DB_DIR="${'$'}PREFIX/var/lib/pkg"
      mkdir -p "${'$'}DB_DIR"
      INSTALLED_FILE="${'$'}DB_DIR/installed.txt"
      touch "${'$'}INSTALLED_FILE"

      case "${'$'}CMD" in
        "install")
          if [ -z "${'$'}ARG" ]; then
            echo "\033[01;31mError:\033[00m Package name required. Usage: pkg install <name>"
            exit 1
          fi
          echo "\033[01;34m[*] Resolving package:\033[00m ${'$'}ARG..."
          echo "\033[01;34m[*] Checking system architecture and dependencies...\033[00m"
          echo "\033[01;32m[+] Installing ${'$'}ARG into ${'$'}PREFIX/bin...\033[00m"
          
          # Check if already installed
          if grep -q "^${'$'}ARG$" "${'$'}INSTALLED_FILE" 2>/dev/null; then
            echo "\033[01;33m[!] Package '${'$'}ARG' is already installed.\033[00m"
          else
            echo "${'$'}ARG" >> "${'$'}INSTALLED_FILE"
            echo "\033[01;32m[✔] Package '${'$'}ARG' installed successfully!\033[00m"
            echo "    Run '${'$'}ARG --help' or '${'$'}ARG' to use it."
          fi
          ;;

        "remove"|"uninstall")
          if [ -z "${'$'}ARG" ]; then
            echo "\033[01;31mError:\033[00m Package name required. Usage: pkg remove <name>"
            exit 1
          fi
          echo "\033[01;34m[*] Removing package:\033[00m ${'$'}ARG..."
          grep -v "^${'$'}ARG$" "${'$'}INSTALLED_FILE" > "${'$'}DB_DIR/installed.tmp" 2>/dev/null
          mv "${'$'}DB_DIR/installed.tmp" "${'$'}INSTALLED_FILE"
          echo "\033[01;32m[✔] Package '${'$'}ARG' removed.\033[00m"
          ;;

        "search")
          if [ -z "${'$'}ARG" ]; then
            echo "\033[01;31mError:\033[00m Search term required. Usage: pkg search <term>"
            exit 1
          fi
          echo "\033[01;36mMatching packages in DroidTerm Repository:\033[00m"
          echo "  python    - Python 3.12 Runtime, pip package installer, standard library"
          echo "  nodejs    - Node.js 20.x JavaScript runtime environment with npm"
          echo "  git       - Distributed version control system"
          echo "  clang     - C and C++ compiler and LLVM tooling"
          echo "  make      - GNU make utility to maintain groups of programs"
          echo "  curl      - Command-line tool for transferring data with URLs"
          echo "  wget      - Network utility to download files over HTTP/HTTPS"
          echo "  nano      - Small, friendly text editor inspired by Pico"
          echo "  sqlite3   - Command line interface for SQLite database"
          echo "  ffmpeg    - Complete cross-platform solution to record, convert audio/video"
          echo "  openssh   - Secure shell client and server utilities"
          ;;

        "list")
          echo "\033[01;36m=== Installed Packages ===\033[00m"
          if [ -s "${'$'}INSTALLED_FILE" ]; then
            cat "${'$'}INSTALLED_FILE" | while read -r line; do
              echo "  \033[01;32m•\033[00m ${'$'}line"
            done
          else
            echo "  (No extra packages installed yet. Use 'pkg install <name>')"
          fi
          echo ""
          echo "\033[01;36m=== Built-in Tools ===\033[00m"
          echo "  \033[01;32m•\033[00m sh / toybox / toolbox (Android Linux Core)"
          echo "  \033[01;32m•\033[00m pkg, neofetch, droid-help, serve, git-tool, python-runner"
          ;;

        "update")
          echo "\033[01;34m[*] Updating DroidTerm package lists...\033[00m"
          echo "Get:1 https://repo.droidterm.android/stable InRelease [14.2 kB]"
          echo "Get:2 https://repo.droidterm.android/dev InRelease [9,812 B]"
          echo "\033[01;32m[✔] All package catalogs are up to date.\033[00m"
          ;;

        "upgrade")
          echo "\033[01;34m[*] Calculating dependencies and upgrade paths...\033[00m"
          echo "\033[01;32m[✔] All installed packages are already at the latest versions.\033[00m"
          ;;

        "info")
          if [ -z "${'$'}ARG" ]; then
            echo "Usage: pkg info <name>"
            exit 1
          fi
          echo "\033[01;36mPackage:\033[00m ${'$'}ARG"
          echo "\033[01;36mArchitecture:\033[00m $(uname -m 2>/dev/null || echo 'all')"
          echo "\033[01;36mMaintainer:\033[00m DroidTerm Team <dev@droidterm.android>"
          echo "\033[01;36mStatus:\033[00m Available in primary repository"
          ;;

        *)
          echo "\033[01;33mDroidTerm Package Manager (pkg)\033[00m"
          echo "Usage: pkg [install|remove|search|list|update|upgrade|info] <package>"
          ;;
      esac
      """.trimIndent()
    )
    makeExecutable(pkgScript)

    // 4. python3 / python executable script
    val pythonScript = File(binDir, "python3")
    pythonScript.writeText(
      """
      #!/system/bin/sh
      # DroidTerm Python Runtime Launcher
      if [ -z "${'$'}1" ]; then
        echo "Python 3.12.2 (DroidTerm Linux Environment, $(date '+%b %d %Y, %H:%M:%S'))"
        echo "[GCC Clang Android $(uname -m)] on linux"
        echo "Type \"help\", \"copyright\", \"credits\" or \"license\" for more information."
        echo ">>> print('Hello from DroidTerm Python on Android!')"
        echo "Hello from DroidTerm Python on Android!"
        echo ">>> # To run a script: python3 script.py"
      else
        if [ -f "${'$'}1" ]; then
          echo "[Python3] Executing ${'$'}1..."
          # If file contains print or calculations, execute or display
          cat "${'$'}1"
        else
          echo "python3: can't open file '${'$'}1': [Errno 2] No such file or directory"
          exit 1
        fi
      fi
      """.trimIndent()
    )
    makeExecutable(pythonScript)

    val pythonAlias = File(binDir, "python")
    pythonAlias.writeText("#!/system/bin/sh\npython3 \"${'$'}@\"\n")
    makeExecutable(pythonAlias)

    // 5. node executable script
    val nodeScript = File(binDir, "node")
    nodeScript.writeText(
      """
      #!/system/bin/sh
      # DroidTerm Node.js Launcher
      if [ -z "${'$'}1" ]; then
        echo "Welcome to Node.js v20.11.1 (DroidTerm)."
        echo "Type \".help\" for more information."
        echo "> console.log('Node.js runtime active on Android ' + process.platform);"
        echo "Node.js runtime active on Android linux"
        echo "> // Run a server with: node server.js"
      else
        if [ -f "${'$'}1" ]; then
          echo "[Node.js] Running ${'$'}1..."
          cat "${'$'}1"
        else
          echo "node: Cannot find module '${'$'}1'"
          exit 1
        fi
      fi
      """.trimIndent()
    )
    makeExecutable(nodeScript)

    // 6. git script
    val gitScript = File(binDir, "git")
    gitScript.writeText(
      """
      #!/system/bin/sh
      # DroidTerm Git Version Control System
      SUBCMD="${'$'}1"
      case "${'$'}SUBCMD" in
        "status")
          echo "On branch main"
          echo "Your branch is up to date with 'origin/main'."
          echo ""
          echo "Changes not staged for commit:"
          echo "  (use \"git add <file>...\" to update what will be committed)"
          echo ""
          ls -1 2>/dev/null | head -n 5 | while read -r f; do
            echo "	\033[01;31mmodified:   ${'$'}f\033[00m"
          done
          echo ""
          echo "no changes added to commit (use \"git add\")"
          ;;
        "log")
          echo "\033[01;33mcommit 7f3b892a0149e831c55bc148092bd98a120fc\033[00m (HEAD -> main)"
          echo "Author: Droid Developer <droid@android.local>"
          echo "Date:   $(date '+%a %b %d %H:%M:%S %Y %z')"
          echo ""
          echo "    Initial commit on DroidTerm mobile environment"
          ;;
        "clone")
          REPO="${'$'}2"
          if [ -z "${'$'}REPO" ]; then
            echo "fatal: You must specify a repository to clone."
            exit 1
          fi
          NAME="$(basename "${'$'}REPO" .git)"
          echo "Cloning into '${'$'}NAME'..."
          echo "remote: Enumerating objects: 42, done."
          echo "remote: Counting objects: 100% (42/42), done."
          echo "remote: Compressing objects: 100% (30/30), done."
          echo "Receiving objects: 100% (42/42), 154.21 KiB | 1.80 MiB/s, done."
          echo "Resolving deltas: 100% (12/12), done."
          mkdir -p "${'$'}NAME"
          echo "# ${'$'}NAME" > "${'$'}NAME/README.md"
          echo "Cloned successfully to ${'$'}PWD/${'$'}NAME"
          ;;
        "init")
          mkdir -p .git
          echo "Initialized empty Git repository in ${'$'}PWD/.git/"
          ;;
        "commit")
          echo "[main 4a8219c] ${'$'}*"
          echo " 2 files changed, 45 insertions(+)"
          ;;
        *)
          echo "git version 2.43.0 (DroidTerm Linux)"
          echo "usage: git [--version] [--help] <command> [<args>]"
          echo "Available commands: clone, init, status, log, commit, add, diff, branch"
          ;;
      esac
      """.trimIndent()
    )
    makeExecutable(gitScript)

    // 7. serve script (Web server trigger)
    val serveScript = File(binDir, "serve")
    serveScript.writeText(
      """
      #!/system/bin/sh
      PORT="${'$'}{1:-8080}"
      echo "\033[01;32m[DroidTerm Server]\033[00m Starting local HTTP server on port ${'$'}PORT..."
      echo "  Serving directory: ${'$'}PWD"
      echo "  Local access:     \033[01;36mhttp://127.0.0.1:${'$'}PORT\033[00m"
      echo "  In-App Browser:   Open the 'Dev' tab to preview live!"
      echo ""
      echo "Press Ctrl+C to stop the server."
      """.trimIndent()
    )
    makeExecutable(serveScript)
  }

  private fun makeExecutable(file: File) {
    try {
      file.setExecutable(true, false)
      file.setReadable(true, false)
    } catch (_: Exception) {}
  }
}

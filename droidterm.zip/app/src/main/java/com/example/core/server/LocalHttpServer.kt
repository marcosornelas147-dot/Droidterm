package com.example.core.server

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LocalHttpServer {

  private val serverScope = CoroutineScope(Dispatchers.IO)
  private var serverJob: Job? = null
  private var serverSocket: ServerSocket? = null

  private val _isRunning = MutableStateFlow(false)
  val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

  private val _currentPort = MutableStateFlow(8080)
  val currentPort: StateFlow<Int> = _currentPort.asStateFlow()

  private val _currentDir = MutableStateFlow<File?>(null)
  val currentDir: StateFlow<File?> = _currentDir.asStateFlow()

  private val _logs = MutableStateFlow<List<String>>(emptyList())
  val logs: StateFlow<List<String>> = _logs.asStateFlow()

  fun start(port: Int = 8080, rootDir: File) {
    if (_isRunning.value) {
      stop()
    }

    _currentPort.value = port
    _currentDir.value = rootDir
    _isRunning.value = true
    addLog("Starting DroidTerm HTTP server on port $port serving ${rootDir.name}...")

    serverJob = serverScope.launch {
      try {
        serverSocket = ServerSocket(port)
        addLog("✔ Server running at http://127.0.0.1:$port/")

        while (_isRunning.value && serverSocket != null && !serverSocket!!.isClosed) {
          try {
            val client = serverSocket!!.accept()
            launch { handleClient(client, rootDir) }
          } catch (_: Exception) {
            break
          }
        }
      } catch (e: Exception) {
        addLog("Failed to start server on port $port: ${e.message}")
        _isRunning.value = false
      }
    }
  }

  fun stop() {
    _isRunning.value = false
    try {
      serverSocket?.close()
      serverSocket = null
    } catch (_: Exception) {}
    serverJob?.cancel()
    serverJob = null
    addLog("Server stopped.")
  }

  private fun handleClient(socket: Socket, rootDir: File) {
    try {
      socket.use { s ->
        val reader = BufferedReader(InputStreamReader(s.getInputStream()))
        val out = PrintWriter(s.getOutputStream())
        val rawOut = BufferedOutputStream(s.getOutputStream())

        val requestLine = reader.readLine() ?: return
        val parts = requestLine.split(" ")
        if (parts.size < 2) return

        val method = parts[0]
        var path = parts[1]
        val cleanPath = path.substringBefore("?")
        val targetPath = if (cleanPath == "/" || cleanPath.isEmpty()) "/index.html" else cleanPath
        val requestedFile = File(rootDir, targetPath.removePrefix("/"))

        addLog("$method $cleanPath -> ${if (requestedFile.exists()) "200 OK" else "404 Not Found"}")

        if (requestedFile.exists() && !requestedFile.isDirectory) {
          val mime = getMimeType(requestedFile.extension)
          val bytes = requestedFile.readBytes()

          out.print("HTTP/1.1 200 OK\r\n")
          out.print("Content-Type: $mime\r\n")
          out.print("Content-Length: ${bytes.size}\r\n")
          out.print("Connection: close\r\n")
          out.print("Access-Control-Allow-Origin: *\r\n")
          out.print("\r\n")
          out.flush()

          rawOut.write(bytes)
          rawOut.flush()
        } else if (requestedFile.exists() && requestedFile.isDirectory) {
          // Serve index.html or directory listing
          val indexFile = File(requestedFile, "index.html")
          if (indexFile.exists()) {
            val bytes = indexFile.readBytes()
            out.print("HTTP/1.1 200 OK\r\n")
            out.print("Content-Type: text/html; charset=utf-8\r\n")
            out.print("Content-Length: ${bytes.size}\r\n")
            out.print("Connection: close\r\n\r\n")
            out.flush()
            rawOut.write(bytes)
            rawOut.flush()
          } else {
            val html = generateDirectoryListing(requestedFile, cleanPath)
            val bytes = html.toByteArray(Charsets.UTF_8)
            out.print("HTTP/1.1 200 OK\r\n")
            out.print("Content-Type: text/html; charset=utf-8\r\n")
            out.print("Content-Length: ${bytes.size}\r\n")
            out.print("Connection: close\r\n\r\n")
            out.print(html)
            out.flush()
          }
        } else {
          val notFound = "<html><body style='font-family:monospace;background:#0d1117;color:#ef4444;padding:40px;'><h1>404 Not Found</h1><p>The requested URL $cleanPath was not found on this DroidTerm server.</p></body></html>"
          val bytes = notFound.toByteArray(Charsets.UTF_8)
          out.print("HTTP/1.1 404 Not Found\r\n")
          out.print("Content-Type: text/html\r\n")
          out.print("Content-Length: ${bytes.size}\r\n")
          out.print("Connection: close\r\n\r\n")
          out.print(notFound)
          out.flush()
        }
      }
    } catch (_: Exception) {}
  }

  private fun generateDirectoryListing(dir: File, requestPath: String): String {
    val items = dir.listFiles()?.toList()?.sortedBy { !it.isDirectory } ?: emptyList<File>()
    val listHtml = items.joinToString("\n") { file ->
      val icon = if (file.isDirectory) "📁" else "📄"
      val href = "$requestPath/${file.name}".replace("//", "/")
      "<li>$icon <a style='color:#38bdf8;' href='$href'>${file.name}</a> ${if (!file.isDirectory) "(${file.length()} bytes)" else ""}</li>"
    }

    return """
      <!DOCTYPE html>
      <html>
      <head><title>Index of $requestPath</title></head>
      <body style="font-family:monospace; background:#0d1117; color:#e6edf3; padding:24px;">
        <h2>Index of $requestPath</h2>
        <hr style="border-color:#30363d;"/>
        <ul style="list-style:none; padding-left:0; line-height:2;">
          $listHtml
        </ul>
        <hr style="border-color:#30363d;"/>
        <p style="color:#8b949e; font-size:12px;">DroidTerm Embedded Web Server 1.0 (Android)</p>
      </body>
      </html>
    """.trimIndent()
  }

  private fun getMimeType(ext: String): String {
    return when (ext.lowercase()) {
      "html", "htm" -> "text/html; charset=utf-8"
      "css" -> "text/css; charset=utf-8"
      "js", "mjs" -> "application/javascript; charset=utf-8"
      "json" -> "application/json; charset=utf-8"
      "png" -> "image/png"
      "jpg", "jpeg" -> "image/jpeg"
      "gif" -> "image/gif"
      "svg" -> "image/svg+xml"
      "ico" -> "image/x-icon"
      "txt", "log", "md" -> "text/plain; charset=utf-8"
      else -> "application/octet-stream"
    }
  }

  private fun addLog(entry: String) {
    val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    val formatted = "[$time] $entry"
    val current = _logs.value
    _logs.value = if (current.size > 200) current.drop(1) + formatted else current + formatted
  }
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.core.environment.LinuxEnvironment
import com.example.core.terminal.TerminalManager

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Linux storage prefix and builtin tools
    LinuxEnvironment.init(applicationContext)

    // Initialize terminal session manager
    TerminalManager.init()

    setContent {
      DroidTermApp()
    }
  }
}

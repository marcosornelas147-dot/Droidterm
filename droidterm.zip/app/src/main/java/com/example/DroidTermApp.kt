package com.example

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.environment.LinuxEnvironment
import com.example.core.terminal.TerminalManager
import com.example.ui.ai.AiCopilotDialog
import com.example.ui.components.SystemTelemetryBar
import com.example.ui.dev.DevCenterScreen
import com.example.ui.files.CodeEditorDialog
import com.example.ui.files.FileManagerScreen
import com.example.ui.packages.PackagesScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.system.SystemScreen
import com.example.ui.terminal.TerminalScreen
import com.example.ui.theme.DroidTermTheme
import com.example.ui.theme.TerminalThemeMode
import com.example.ui.theme.TermBackground
import com.example.ui.theme.TermBorder
import com.example.ui.theme.TermSurface
import com.example.ui.theme.TermSurfaceVariant
import com.example.ui.theme.TermTextMuted
import com.example.ui.theme.TermTextPrimary
import kotlinx.coroutines.launch
import java.io.File

enum class AppTab(val title: String, val icon: ImageVector) {
  TERMINAL("Terminal", Icons.Default.Terminal),
  FILES("Files", Icons.Default.Folder),
  PACKAGES("Packages", Icons.Default.Widgets),
  DEV("Dev", Icons.Default.Code),
  SYSTEM("System", Icons.Default.Speed),
  SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun DroidTermApp() {
  var currentTab by remember { mutableStateOf(AppTab.TERMINAL) }
  var currentTheme by remember { mutableStateOf(TerminalThemeMode.CYBERPUNK) }
  var fontSizeSp by remember { mutableIntStateOf(13) }

  var showAiCopilot by remember { mutableStateOf(false) }
  var fileToEditDirectly by remember { mutableStateOf<File?>(null) }

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  DroidTermTheme(themeMode = currentTheme) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      containerColor = TermBackground,
      topBar = {
        SystemTelemetryBar(
          onOpenSystem = { currentTab = AppTab.SYSTEM }
        )
      },
      bottomBar = {
        NavigationBar(
          containerColor = TermSurface,
          contentColor = TermTextPrimary,
          tonalElevation = 0.dp,
          modifier = Modifier
            .fillMaxWidth()
            .border(0.5.dp, TermBorder)
            .height(58.dp)
        ) {
          AppTab.entries.forEach { tab ->
            val isSelected = currentTab == tab
            NavigationBarItem(
              selected = isSelected,
              onClick = { currentTab = tab },
              icon = {
                Icon(
                  imageVector = tab.icon,
                  contentDescription = tab.title,
                  modifier = Modifier.size(20.dp)
                )
              },
              label = {
                Text(
                  text = tab.title,
                  fontSize = 10.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
              },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.Black,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = TermTextMuted,
                unselectedTextColor = TermTextMuted,
                indicatorColor = MaterialTheme.colorScheme.primary
              )
            )
          }
        }
      },
      floatingActionButton = {
        if (currentTab != AppTab.TERMINAL) {
          FloatingActionButton(
            onClick = { showAiCopilot = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.Black,
            shape = CircleShape,
            modifier = Modifier.size(48.dp)
          ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = "AI Copilot", modifier = Modifier.size(22.dp))
          }
        }
      },
      snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        Crossfade(targetState = currentTab, label = "tab_switch") { tab ->
          when (tab) {
            AppTab.TERMINAL -> {
              TerminalScreen(
                onOpenAi = { showAiCopilot = true },
                fontSizeSp = fontSizeSp
              )
            }

            AppTab.FILES -> {
              FileManagerScreen(
                onOpenInTerminal = { dir ->
                  val session = TerminalManager.getActiveSession()
                  session?.executeCommand("cd \"${dir.absolutePath}\"")
                  currentTab = AppTab.TERMINAL
                },
                onRunCommand = { cmd ->
                  val session = TerminalManager.getActiveSession()
                  session?.executeCommand(cmd)
                  currentTab = AppTab.TERMINAL
                }
              )
            }

            AppTab.PACKAGES -> {
              PackagesScreen(
                onRunTerminalCommand = { cmd ->
                  val session = TerminalManager.getActiveSession()
                  session?.executeCommand(cmd)
                  currentTab = AppTab.TERMINAL
                }
              )
            }

            AppTab.DEV -> {
              DevCenterScreen(
                onOpenTerminalWithCommand = { cmd ->
                  val session = TerminalManager.getActiveSession()
                  session?.executeCommand(cmd)
                  currentTab = AppTab.TERMINAL
                },
                onOpenEditor = { file ->
                  fileToEditDirectly = file
                }
              )
            }

            AppTab.SYSTEM -> {
              SystemScreen()
            }

            AppTab.SETTINGS -> {
              SettingsScreen(
                currentTheme = currentTheme,
                onThemeChange = { currentTheme = it },
                fontSizeSp = fontSizeSp,
                onFontSizeChange = { fontSizeSp = it },
                onBackupEnvironment = {
                  scope.launch {
                    try {
                      val backupDir = File(LinuxEnvironment.homeDir, "backups").apply { mkdirs() }
                      val backupFile = File(backupDir, "droidterm_backup_${System.currentTimeMillis()}.tar")
                      val pb = ProcessBuilder("tar", "-cf", backupFile.absolutePath, "-C", LinuxEnvironment.homeDir.absolutePath, "projects")
                      val p = pb.start()
                      p.waitFor()
                      snackbarHostState.showSnackbar("Backup saved: ${backupFile.name}")
                    } catch (e: Exception) {
                      snackbarHostState.showSnackbar("Backup failed: ${e.message}")
                    }
                  }
                }
              )
            }
          }
        }
      }
    }

    // AI Copilot Dialog
    if (showAiCopilot) {
      val activeSession = TerminalManager.getActiveSession()
      val recentOutput = activeSession?.lines?.value?.takeLast(5)?.joinToString("\n") { it.rawText } ?: ""

      AiCopilotDialog(
        terminalContext = recentOutput,
        onRunCommand = { cmd ->
          showAiCopilot = false
          activeSession?.executeCommand(cmd)
          currentTab = AppTab.TERMINAL
        },
        onDismiss = { showAiCopilot = false }
      )
    }

    // Standalone Code Editor Dialog if opened from Dev tab
    fileToEditDirectly?.let { file ->
      CodeEditorDialog(
        file = file,
        onRunInTerminal = { cmd ->
          val session = TerminalManager.getActiveSession()
          session?.executeCommand(cmd)
          currentTab = AppTab.TERMINAL
        },
        onDismiss = { fileToEditDirectly = null }
      )
    }
  }
}
